# MyTeeCanvas

A premium fashion e-commerce website for men's streetwear and minimal apparel, built with TanStack Start and deployed on Netlify.

## About

MyTeeCanvas sells oversized drop shoulder t-shirts, polo shirts, basic tees, streetwear, and hoodies through a dropshipping model. The brand targets university students and young adults aged 16–28 with a minimal-premium aesthetic inspired by Zara, H&M, and Represent Clothing.

## Key Features

- **Home page** — Hero section, best sellers, trending products, limited edition banner, custom design CTA, customer reviews, Instagram-style gallery
- **Shop page** — Filter by category, size, color, price; sort options; search
- **Product detail** — Image gallery with zoom, size/color selector, quantity picker, reviews, related products, urgency signals
- **Custom Design page** — Drag-and-drop file upload, AI design prompt generator, apparel customizer, live price calculator, WhatsApp/Messenger designer contact
- **About page** — Brand story, values, stats, manifesto
- **Contact page** — Contact form, WhatsApp/Messenger/email buttons, FAQ accordion
- **Wishlist** — Persist across sessions via localStorage
- **Cart drawer** — Slide-in cart with quantity control, coupon code field, persistent via localStorage
- **Dark/Light mode** — Toggle in navbar
- **Mobile-first** — Floating cart button, responsive filters drawer, touch-friendly

## Tech Stack

| Layer | Technology |
|-------|------------|
| Framework | TanStack Start (React + Vite) |
| Router | TanStack Router v1 (file-based) |
| Styling | Tailwind CSS 4 + custom CSS animations |
| Icons | Lucide React |
| State | React Context (CartContext, WishlistContext) |
| Persistence | localStorage |
| Fonts | Google Fonts — Inter + Playfair Display |
| Deployment | Netlify |

## Running Locally

```bash
npm install
npm run dev        # starts at http://localhost:3000
```

## Environment Variables

```
STRIPE_SECRET_KEY=...    # Required for Stripe checkout (optional)
SITE_URL=...             # Your deployed site URL
```

## Build

```bash
npm run build
```
