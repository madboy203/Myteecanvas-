# AGENTS.md — MyTeeCanvas

Premium fashion e-commerce website. Built with TanStack Start, deployed on Netlify. Target audience: university students aged 16–28. Brand: minimal-premium black/white/grey/beige streetwear.

---

## Tech Stack

- **Framework**: TanStack Start (SSR React + Vite 7)
- **Routing**: TanStack Router v1 — file-based, auto-generated `routeTree.gen.ts`
- **Styling**: Tailwind CSS 4 + custom CSS in `src/styles.css`
- **State**: React Context (`CartContext`, `WishlistContext`) with localStorage persistence
- **Icons**: Lucide React
- **Fonts**: Google Fonts — Inter (body) + Playfair Display (headings/display)
- **Payments**: Stripe (server functions in `src/lib/stripe.ts`)
- **Deployment**: Netlify via `@netlify/vite-plugin-tanstack-start`

## Directory Structure

```
src/
  components/
    Navbar.tsx           # Sticky nav, transparent on hero, search, dark/light toggle
    Footer.tsx           # Newsletter, links, social icons
    ProductCard.tsx      # Product card with hover overlay, wishlist, quick-add
    CartDrawer.tsx       # Slide-in cart from right
    BuyButton.tsx        # Stripe checkout button
  context/
    CartContext.tsx      # Cart state + isOpen drawer state, localStorage-backed
    WishlistContext.tsx  # Wishlist state, localStorage-backed
  data/
    products.ts          # Product catalog — Product interface + 8 products
  lib/
    stripe.ts            # createCheckoutSession + getStripeEnabled server fns
  routes/
    __root.tsx           # Root layout: CartProvider, WishlistProvider, Navbar, CartDrawer, Footer
    index.tsx            # Home page
    shop.tsx             # Shop page with filter sidebar
    about.tsx            # Brand story page
    contact.tsx          # Contact form + FAQ
    wishlist.tsx         # Wishlist page
    custom-design.tsx    # Custom apparel design page with AI prompt
    products/
      $productId.tsx     # Product detail page
    checkout/
      success.tsx        # Stripe success page
      cancel.tsx         # Stripe cancel page
  styles.css             # Tailwind + CSS variables + keyframe animations
  router.tsx             # createRouter with routeTree.gen
```

## Key Conventions

### Routing
File-based routing; `src/routeTree.gen.ts` is auto-generated at build/dev — never edit it.

### Product Data (`src/data/products.ts`)
`Product` type fields: `id`, `name`, `category`, `image`, `images[]`, `price`, `originalPrice?`, `sizes[]`, `colors[]`, `fabric`, flags (`isNew`, `isBestSeller`, `isTrending`, `isLimitedEdition`), `stock`, `soldThisWeek`, `rating`, `reviewCount`, `tags[]`.

### Cart / Wishlist
- `useCart()` hook — items, add/remove/update, totalItems/Price, openCart/closeCart
- `useWishlist()` hook — items, toggle, isWishlisted
- Both use localStorage keys `mtc-cart` and `mtc-wishlist`
- Providers mounted in `__root.tsx`

### Styling Patterns
- CSS vars in `styles.css`: `--color-black`, `--color-white`, `--font-body`, `--font-display`
- `section-title` → Playfair Display font
- `img-zoom-container` → hover zoom on child `img`
- `product-card` + `product-card-overlay` → hover reveal overlay
- `btn-magnetic` → scale-up on hover
- `animate-fade-in`, `animate-scale-in`, `animate-marquee`
- `trust-badge` → invert-on-hover

### Images
Unsplash CDN: `images.unsplash.com/photo-{id}?w=600&q=80`. Use `w=400` for thumbnails, `w=1600` for heroes.

### Dark Mode
Toggled in Navbar via `document.documentElement.classList.toggle('dark', dark)`. No server persistence.

### Stripe
`src/lib/stripe.ts` — requires `STRIPE_SECRET_KEY` env var. BuyButton auto-disables if unset.

## Environment Variables

```
STRIPE_SECRET_KEY=...    # Optional — enables Stripe checkout
SITE_URL=...             # Your deployed URL
```

## Commands

```bash
npm run dev     # dev server at localhost:3000
npm run build   # production build
```
