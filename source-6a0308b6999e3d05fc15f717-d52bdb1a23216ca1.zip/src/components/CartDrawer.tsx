import { X, ShoppingBag, Minus, Plus, Trash2, ArrowRight } from 'lucide-react'
import { useCart } from '@/context/CartContext'
import { Link } from '@tanstack/react-router'

export function CartDrawer() {
  const { items, isOpen, closeCart, removeItem, updateQuantity, totalItems, totalPrice } =
    useCart()

  if (!isOpen) return null

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/40 z-50 backdrop-blur-sm"
        onClick={closeCart}
      />

      {/* Drawer */}
      <div className="fixed top-0 right-0 h-full w-full max-w-md bg-white dark:bg-black z-50 cart-drawer flex flex-col shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-black/8 dark:border-white/8">
          <div className="flex items-center gap-3">
            <ShoppingBag size={20} />
            <h2 className="font-semibold text-lg">
              Cart {totalItems > 0 && <span className="text-black/40 dark:text-white/40 font-normal text-base">({totalItems})</span>}
            </h2>
          </div>
          <button
            onClick={closeCart}
            className="w-8 h-8 rounded-full hover:bg-black/5 dark:hover:bg-white/5 flex items-center justify-center transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Items */}
        <div className="flex-1 overflow-y-auto py-4 px-6">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center">
              <ShoppingBag size={48} className="text-black/20 dark:text-white/20 mb-4" />
              <h3 className="font-semibold text-lg mb-2">Your cart is empty</h3>
              <p className="text-black/40 dark:text-white/40 text-sm mb-6">
                Discover our premium streetwear collection
              </p>
              <button
                onClick={closeCart}
                className="px-6 py-3 bg-black dark:bg-white text-white dark:text-black text-sm font-semibold rounded-xl"
              >
                <Link to="/shop">Shop Now</Link>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {items.map((item) => (
                <div
                  key={`${item.product.id}-${item.size}-${item.color}`}
                  className="flex gap-4 py-4 border-b border-black/5 dark:border-white/5"
                >
                  <div className="w-20 h-24 rounded-xl overflow-hidden bg-[#f5f0eb] flex-shrink-0">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-sm font-semibold leading-tight line-clamp-2">
                      {item.product.name}
                    </h4>
                    <p className="text-xs text-black/40 dark:text-white/40 mt-1">
                      {item.size} · {item.color}
                    </p>
                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() =>
                            updateQuantity(
                              item.product.id,
                              item.size,
                              item.color,
                              item.quantity - 1,
                            )
                          }
                          className="w-6 h-6 rounded-full border border-black/15 dark:border-white/15 flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                        >
                          <Minus size={11} />
                        </button>
                        <span className="text-sm font-medium w-5 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() =>
                            updateQuantity(
                              item.product.id,
                              item.size,
                              item.color,
                              item.quantity + 1,
                            )
                          }
                          className="w-6 h-6 rounded-full border border-black/15 dark:border-white/15 flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                        >
                          <Plus size={11} />
                        </button>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold">
                          ${(item.product.price * item.quantity).toFixed(2)}
                        </span>
                        <button
                          onClick={() =>
                            removeItem(item.product.id, item.size, item.color)
                          }
                          className="w-6 h-6 rounded-full text-red-400 hover:bg-red-50 flex items-center justify-center transition-colors"
                        >
                          <Trash2 size={12} />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        {items.length > 0 && (
          <div className="px-6 py-6 border-t border-black/8 dark:border-white/8 space-y-4">
            {/* Coupon */}
            <div className="flex gap-2">
              <input
                type="text"
                placeholder="Coupon code"
                className="flex-1 px-4 py-2.5 text-sm border border-black/10 dark:border-white/10 rounded-lg bg-transparent focus:outline-none focus:border-black dark:focus:border-white transition-colors"
              />
              <button className="px-4 py-2.5 text-sm font-semibold border border-black/15 dark:border-white/15 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 transition-colors">
                Apply
              </button>
            </div>

            {/* Subtotal */}
            <div className="flex items-center justify-between text-sm">
              <span className="text-black/50 dark:text-white/50">Subtotal</span>
              <span className="font-bold text-base">${totalPrice.toFixed(2)}</span>
            </div>
            <p className="text-xs text-black/30 dark:text-white/30">
              Shipping & taxes calculated at checkout
            </p>

            <button
              onClick={closeCart}
              className="w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 hover:opacity-90 transition-opacity"
            >
              Checkout
              <ArrowRight size={16} />
            </button>

            <button
              onClick={closeCart}
              className="w-full text-black/40 dark:text-white/40 text-sm text-center hover:text-black dark:hover:text-white transition-colors"
            >
              <Link to="/shop">Continue Shopping</Link>
            </button>
          </div>
        )}
      </div>
    </>
  )
}
