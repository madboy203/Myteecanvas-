import { Link } from '@tanstack/react-router'
import { Instagram, Twitter, Youtube, Mail, Phone, MapPin } from 'lucide-react'

export function Footer() {
  return (
    <footer className="bg-black text-white">
      {/* Newsletter */}
      <div className="border-b border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="max-w-xl">
            <p className="text-xs font-semibold tracking-[0.2em] text-white/40 uppercase mb-3">
              Stay in the loop
            </p>
            <h3
              className="text-3xl lg:text-4xl font-bold mb-4"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Get Early Access
            </h3>
            <p className="text-white/50 mb-6">
              New drops, exclusive discounts, and style tips — straight to your inbox.
            </p>
            <form className="flex gap-3" onSubmit={(e) => e.preventDefault()}>
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-sm text-white placeholder:text-white/30 focus:outline-none focus:border-white/40 transition-colors"
              />
              <button
                type="submit"
                className="px-6 py-3 bg-white text-black text-sm font-semibold rounded-lg hover:bg-white/90 transition-colors whitespace-nowrap"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>

      {/* Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <Link to="/">
              <span
                className="text-2xl font-black tracking-tight"
                style={{ fontFamily: 'var(--font-display)' }}
              >
                MyTeeCanvas
              </span>
            </Link>
            <p className="mt-4 text-white/40 text-sm leading-relaxed max-w-xs">
              Premium drop shoulder & streetwear for those who move with intention. Minimal. Confident. Yours.
            </p>
            <div className="flex items-center gap-3 mt-6">
              <a
                href="#"
                className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-white/50 hover:text-white hover:border-white transition-colors"
                aria-label="Instagram"
              >
                <Instagram size={15} />
              </a>
              <a
                href="#"
                className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-white/50 hover:text-white hover:border-white transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={15} />
              </a>
              <a
                href="#"
                className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-white/50 hover:text-white hover:border-white transition-colors"
                aria-label="YouTube"
              >
                <Youtube size={15} />
              </a>
              <a
                href="https://wa.me/1234567890"
                className="w-9 h-9 rounded-full border border-white/15 flex items-center justify-center text-white/50 hover:text-white hover:border-white transition-colors text-xs font-bold"
                aria-label="WhatsApp"
              >
                WA
              </a>
            </div>
          </div>

          {/* Shop */}
          <div>
            <h4 className="text-xs font-semibold tracking-[0.2em] text-white/40 uppercase mb-5">Shop</h4>
            <ul className="space-y-3">
              {['New Arrivals', 'Oversized Tees', 'Polo Shirts', 'Basic Tees', 'Streetwear', 'Hoodies', 'Sale'].map(
                (item) => (
                  <li key={item}>
                    <Link
                      to="/shop"
                      className="text-sm text-white/50 hover:text-white transition-colors"
                    >
                      {item}
                    </Link>
                  </li>
                ),
              )}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-xs font-semibold tracking-[0.2em] text-white/40 uppercase mb-5">Company</h4>
            <ul className="space-y-3">
              {[
                { label: 'About Us', href: '/about' },
                { label: 'Custom Design', href: '/custom-design' },
                { label: 'Contact', href: '/contact' },
                { label: 'FAQ', href: '/contact' },
                { label: 'Careers', href: '#' },
              ].map((item) => (
                <li key={item.label}>
                  <Link
                    to={item.href}
                    className="text-sm text-white/50 hover:text-white transition-colors"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Help */}
          <div>
            <h4 className="text-xs font-semibold tracking-[0.2em] text-white/40 uppercase mb-5">Help</h4>
            <ul className="space-y-3">
              {['Shipping Info', 'Returns', 'Size Guide', 'Order Tracking', 'Privacy Policy', 'Terms of Use'].map(
                (item) => (
                  <li key={item}>
                    <a href="#" className="text-sm text-white/50 hover:text-white transition-colors">
                      {item}
                    </a>
                  </li>
                ),
              )}
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/30 text-xs">
            © 2025 MyTeeCanvas. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <span className="text-white/30 text-xs">🔒 Secure Checkout</span>
            <span className="text-white/30 text-xs">🚚 Free Shipping</span>
            <span className="text-white/30 text-xs">↩ Easy Returns</span>
          </div>
        </div>
      </div>
    </footer>
  )
}
