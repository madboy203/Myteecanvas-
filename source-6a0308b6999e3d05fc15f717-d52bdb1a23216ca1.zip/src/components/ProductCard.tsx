import { Link } from '@tanstack/react-router'
import { Heart, ShoppingBag, Star } from 'lucide-react'
import type { Product } from '@/data/products'
import { useCart } from '@/context/CartContext'
import { useWishlist } from '@/context/WishlistContext'

interface ProductCardProps {
  product: Product
  className?: string
}

export function ProductCard({ product, className = '' }: ProductCardProps) {
  const { addItem } = useCart()
  const { toggle, isWishlisted } = useWishlist()
  const wishlisted = isWishlisted(product.id)

  const discount =
    product.originalPrice
      ? Math.round((1 - product.price / product.originalPrice) * 100)
      : 0

  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    addItem(product, product.sizes[0], product.colors[0])
  }

  const handleWishlist = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    toggle(product)
  }

  return (
    <div className={`product-card group relative ${className}`}>
      {/* Image */}
      <Link
        to="/products/$productId"
        params={{ productId: product.id.toString() }}
        className="block"
      >
        <div className="relative aspect-[3/4] rounded-2xl overflow-hidden bg-[#f5f0eb] img-zoom-container">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
            loading="lazy"
          />

          {/* Badges */}
          <div className="absolute top-3 left-3 flex flex-col gap-1.5">
            {product.isNew && (
              <span className="bg-black text-white text-[10px] font-semibold px-2.5 py-1 rounded-full tracking-wide">
                NEW
              </span>
            )}
            {product.isLimitedEdition && (
              <span className="bg-amber-500 text-white text-[10px] font-semibold px-2.5 py-1 rounded-full tracking-wide">
                LIMITED
              </span>
            )}
            {discount > 0 && (
              <span className="bg-red-500 text-white text-[10px] font-semibold px-2.5 py-1 rounded-full">
                -{discount}%
              </span>
            )}
          </div>

          {/* Wishlist */}
          <button
            onClick={handleWishlist}
            className={`absolute top-3 right-3 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
              wishlisted
                ? 'bg-black text-white'
                : 'bg-white/80 text-black opacity-0 group-hover:opacity-100'
            }`}
            aria-label="Add to wishlist"
          >
            <Heart size={14} fill={wishlisted ? 'currentColor' : 'none'} />
          </button>

          {/* Add to cart overlay */}
          <div className="product-card-overlay absolute bottom-0 left-0 right-0 p-3 opacity-0 transition-opacity duration-300">
            <button
              onClick={handleAddToCart}
              className="w-full bg-black text-white text-xs font-semibold py-3 rounded-xl hover:bg-black/80 transition-colors flex items-center justify-center gap-2"
            >
              <ShoppingBag size={14} />
              Quick Add
            </button>
          </div>
        </div>

        {/* Info */}
        <div className="mt-3 px-1">
          <div className="flex items-center gap-1 mb-1">
            <div className="flex items-center gap-0.5">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  size={10}
                  className={i < Math.floor(product.rating) ? 'fill-black text-black' : 'fill-none text-black/20'}
                />
              ))}
            </div>
            <span className="text-[10px] text-black/40">({product.reviewCount})</span>
          </div>
          <h3 className="text-sm font-semibold text-black/90 leading-tight line-clamp-2">
            {product.name}
          </h3>
          <div className="flex items-center gap-2 mt-1.5">
            <span className="text-sm font-bold">${product.price}</span>
            {product.originalPrice && (
              <span className="text-xs text-black/40 line-through">${product.originalPrice}</span>
            )}
          </div>
          {/* Color dots */}
          <div className="flex items-center gap-1 mt-2">
            {product.colors.slice(0, 4).map((color) => (
              <span
                key={color}
                className="w-3 h-3 rounded-full border border-black/10"
                style={{
                  background:
                    color === 'Black'
                      ? '#0a0a0a'
                      : color === 'White'
                        ? '#fafafa'
                        : color === 'Beige' || color === 'Cream'
                          ? '#f5f0eb'
                          : color === 'Stone'
                            ? '#d6d3d1'
                            : color === 'Charcoal' || color === 'Slate Grey'
                              ? '#555'
                              : color === 'Navy'
                                ? '#1e3a5f'
                                : '#ddd',
                }}
                title={color}
              />
            ))}
            {product.colors.length > 4 && (
              <span className="text-[10px] text-black/40">+{product.colors.length - 4}</span>
            )}
          </div>
        </div>
      </Link>
    </div>
  )
}
