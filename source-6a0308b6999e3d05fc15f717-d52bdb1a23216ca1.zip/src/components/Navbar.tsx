import { useState, useEffect } from 'react'
import { Link, useLocation } from '@tanstack/react-router'
import {
  ShoppingBag,
  Heart,
  Search,
  Menu,
  X,
  Sun,
  Moon,
  ChevronDown,
} from 'lucide-react'
import { useCart } from '@/context/CartContext'
import { useWishlist } from '@/context/WishlistContext'

const NAV_LINKS = [
  { label: 'Shop', href: '/shop' },
  { label: 'New Arrivals', href: '/shop?filter=new' },
  { label: 'Custom Design', href: '/custom-design' },
  { label: 'About', href: '/about' },
]

export function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [searchOpen, setSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState('')
  const [dark, setDark] = useState(false)
  const { totalItems, openCart } = useCart()
  const { count: wishlistCount } = useWishlist()
  const location = useLocation()

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40)
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  useEffect(() => {
    document.documentElement.classList.toggle('dark', dark)
    document.body.classList.toggle('dark', dark)
  }, [dark])

  useEffect(() => {
    setMobileOpen(false)
  }, [location.pathname])

  const isHome = location.pathname === '/'
  const isTransparent = isHome && !scrolled && !mobileOpen

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          isTransparent
            ? 'bg-transparent text-white'
            : 'bg-white/95 dark:bg-black/95 backdrop-blur-md border-b border-black/8 text-black dark:text-white'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Logo */}
            <Link to="/" className="flex-shrink-0">
              <span
                className={`text-xl lg:text-2xl font-black tracking-tight transition-colors ${
                  isTransparent ? 'text-white' : 'text-black dark:text-white'
                }`}
                style={{ fontFamily: 'var(--font-display)' }}
              >
                MyTeeCanvas
              </span>
            </Link>

            {/* Desktop Nav */}
            <div className="hidden lg:flex items-center gap-8">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  to={link.href.split('?')[0]}
                  className={`nav-link text-sm font-medium tracking-wide transition-colors ${
                    isTransparent
                      ? 'text-white/90 hover:text-white'
                      : 'text-black/70 dark:text-white/70 hover:text-black dark:hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              ))}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 lg:gap-3">
              {/* Search */}
              <button
                onClick={() => setSearchOpen(!searchOpen)}
                className={`p-2 rounded-full transition-colors ${
                  isTransparent
                    ? 'text-white hover:bg-white/10'
                    : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/10'
                }`}
                aria-label="Search"
              >
                <Search size={18} />
              </button>

              {/* Dark mode */}
              <button
                onClick={() => setDark(!dark)}
                className={`p-2 rounded-full transition-colors hidden lg:flex ${
                  isTransparent
                    ? 'text-white hover:bg-white/10'
                    : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/10'
                }`}
                aria-label="Toggle dark mode"
              >
                {dark ? <Sun size={18} /> : <Moon size={18} />}
              </button>

              {/* Wishlist */}
              <Link
                to="/wishlist"
                className={`p-2 rounded-full relative transition-colors hidden sm:flex ${
                  isTransparent
                    ? 'text-white hover:bg-white/10'
                    : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/10'
                }`}
                aria-label="Wishlist"
              >
                <Heart size={18} />
                {wishlistCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-black dark:bg-white text-white dark:text-black text-[9px] font-bold rounded-full flex items-center justify-center badge-pulse">
                    {wishlistCount}
                  </span>
                )}
              </Link>

              {/* Cart */}
              <button
                onClick={openCart}
                className={`p-2 rounded-full relative transition-colors ${
                  isTransparent
                    ? 'text-white hover:bg-white/10'
                    : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/10'
                }`}
                aria-label="Cart"
              >
                <ShoppingBag size={18} />
                {totalItems > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-black dark:bg-white text-white dark:text-black text-[9px] font-bold rounded-full flex items-center justify-center badge-pulse">
                    {totalItems > 9 ? '9+' : totalItems}
                  </span>
                )}
              </button>

              {/* Mobile menu */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className={`p-2 rounded-full transition-colors lg:hidden ${
                  isTransparent
                    ? 'text-white hover:bg-white/10'
                    : 'text-black dark:text-white hover:bg-black/5 dark:hover:bg-white/10'
                }`}
                aria-label="Menu"
              >
                {mobileOpen ? <X size={20} /> : <Menu size={20} />}
              </button>
            </div>
          </div>

          {/* Search bar */}
          {searchOpen && (
            <div className="pb-4 animate-fade-in">
              <div className="relative">
                <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-grey" />
                <input
                  autoFocus
                  type="text"
                  placeholder="Search for oversized tees, polos, hoodies..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-3 bg-black/5 dark:bg-white/10 rounded-xl text-sm placeholder:text-grey focus:outline-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="lg:hidden bg-white dark:bg-black border-t border-black/8 animate-fade-in">
            <div className="px-4 py-6 space-y-1">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.href}
                  to={link.href.split('?')[0]}
                  className="block px-4 py-3 text-sm font-medium text-black/70 dark:text-white/70 hover:text-black dark:hover:text-white hover:bg-black/5 dark:hover:bg-white/5 rounded-lg transition-colors"
                >
                  {link.label}
                </Link>
              ))}
              <div className="pt-4 border-t border-black/8 flex items-center gap-4 px-4">
                <Link to="/wishlist" className="flex items-center gap-2 text-sm">
                  <Heart size={16} />
                  Wishlist {wishlistCount > 0 && `(${wishlistCount})`}
                </Link>
                <button
                  onClick={() => setDark(!dark)}
                  className="flex items-center gap-2 text-sm"
                >
                  {dark ? <Sun size={16} /> : <Moon size={16} />}
                  {dark ? 'Light' : 'Dark'} Mode
                </button>
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Floating cart button (mobile) */}
      <button
        onClick={openCart}
        className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-black text-white rounded-full shadow-2xl flex items-center justify-center lg:hidden transition-transform hover:scale-110 active:scale-95"
        aria-label="Open cart"
      >
        <ShoppingBag size={20} />
        {totalItems > 0 && (
          <span className="absolute -top-1 -right-1 w-5 h-5 bg-white text-black text-[10px] font-bold rounded-full flex items-center justify-center">
            {totalItems > 9 ? '9+' : totalItems}
          </span>
        )}
      </button>
    </>
  )
}
