import React, { createContext, useContext, useEffect, useState } from 'react'
import type { Product } from '@/data/products'

interface WishlistContextValue {
  items: Product[]
  addItem: (product: Product) => void
  removeItem: (productId: number) => void
  isWishlisted: (productId: number) => boolean
  toggle: (product: Product) => void
  count: number
}

const WishlistContext = createContext<WishlistContextValue | null>(null)

export function WishlistProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Product[]>(() => {
    if (typeof window === 'undefined') return []
    try {
      const saved = localStorage.getItem('mtc-wishlist')
      return saved ? JSON.parse(saved) : []
    } catch {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem('mtc-wishlist', JSON.stringify(items))
  }, [items])

  const addItem = (product: Product) => {
    setItems((prev) =>
      prev.find((i) => i.id === product.id) ? prev : [...prev, product],
    )
  }

  const removeItem = (productId: number) => {
    setItems((prev) => prev.filter((i) => i.id !== productId))
  }

  const isWishlisted = (productId: number) => items.some((i) => i.id === productId)

  const toggle = (product: Product) => {
    isWishlisted(product.id) ? removeItem(product.id) : addItem(product)
  }

  return (
    <WishlistContext.Provider
      value={{ items, addItem, removeItem, isWishlisted, toggle, count: items.length }}
    >
      {children}
    </WishlistContext.Provider>
  )
}

export function useWishlist() {
  const ctx = useContext(WishlistContext)
  if (!ctx) throw new Error('useWishlist must be used within WishlistProvider')
  return ctx
}
