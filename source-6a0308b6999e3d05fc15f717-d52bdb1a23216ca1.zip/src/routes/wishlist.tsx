import { createFileRoute, Link } from '@tanstack/react-router'
import { Heart, ShoppingBag, Trash2 } from 'lucide-react'
import { useWishlist } from '@/context/WishlistContext'
import { useCart } from '@/context/CartContext'
import { ProductCard } from '@/components/ProductCard'

export const Route = createFileRoute('/wishlist')({
  component: WishlistPage,
})

function WishlistPage() {
  const { items, removeItem } = useWishlist()
  const { addItem } = useCart()

  return (
    <div className="pt-20 lg:pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="flex items-center gap-3 mb-10">
          <Heart size={24} />
          <h1 className="text-3xl font-bold section-title">
            Wishlist
          </h1>
          {items.length > 0 && (
            <span className="text-black/40 dark:text-white/40 text-lg">({items.length})</span>
          )}
        </div>

        {items.length === 0 ? (
          <div className="text-center py-24">
            <Heart size={48} className="mx-auto text-black/20 dark:text-white/20 mb-4" />
            <h2 className="text-xl font-semibold mb-2">Your wishlist is empty</h2>
            <p className="text-black/40 dark:text-white/40 text-sm mb-8">
              Save items you love to find them easily later
            </p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-black dark:bg-white text-white dark:text-black px-8 py-4 rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              <ShoppingBag size={16} />
              Browse Collection
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {items.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
