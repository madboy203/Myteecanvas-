import { createFileRoute } from '@tanstack/react-router'
import { useState, useMemo } from 'react'
import { SlidersHorizontal, X, ChevronDown, ChevronUp, Search } from 'lucide-react'
import products from '@/data/products'
import { ProductCard } from '@/components/ProductCard'
import type { Product } from '@/data/products'

export const Route = createFileRoute('/shop')({
  component: ShopPage,
})

const CATEGORIES = [
  { value: 'all', label: 'All Styles' },
  { value: 'oversized', label: 'Oversized Tees' },
  { value: 'polo', label: 'Polo Shirts' },
  { value: 'basic-tee', label: 'Basic Tees' },
  { value: 'streetwear', label: 'Streetwear' },
  { value: 'hoodie', label: 'Hoodies' },
]

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL']
const COLORS = ['Black', 'White', 'Beige', 'Stone', 'Charcoal', 'Navy', 'Cream']
const SORT_OPTIONS = [
  { value: 'featured', label: 'Featured' },
  { value: 'newest', label: 'Newest' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'top-rated', label: 'Top Rated' },
]

function FilterSection({
  title,
  children,
  defaultOpen = true,
}: {
  title: string
  children: React.ReactNode
  defaultOpen?: boolean
}) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="border-b border-black/8 dark:border-white/8 pb-5 mb-5">
      <button
        className="flex items-center justify-between w-full text-sm font-semibold mb-3"
        onClick={() => setOpen(!open)}
      >
        {title}
        {open ? <ChevronUp size={15} /> : <ChevronDown size={15} />}
      </button>
      {open && children}
    </div>
  )
}

function ShopPage() {
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedSizes, setSelectedSizes] = useState<string[]>([])
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [priceRange, setPriceRange] = useState([0, 100])
  const [sortBy, setSortBy] = useState('featured')
  const [searchQuery, setSearchQuery] = useState('')
  const [filtersOpen, setFiltersOpen] = useState(false)

  const toggleSize = (size: string) =>
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size],
    )

  const toggleColor = (color: string) =>
    setSelectedColors((prev) =>
      prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color],
    )

  const filtered = useMemo(() => {
    let result = [...products]

    if (selectedCategory !== 'all') {
      result = result.filter((p) => p.category === selectedCategory)
    }
    if (selectedSizes.length > 0) {
      result = result.filter((p) => selectedSizes.some((s) => p.sizes.includes(s)))
    }
    if (selectedColors.length > 0) {
      result = result.filter((p) => selectedColors.some((c) => p.colors.includes(c)))
    }
    result = result.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1],
    )
    if (searchQuery) {
      const q = searchQuery.toLowerCase()
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.tags.some((t) => t.includes(q)) ||
          p.category.includes(q),
      )
    }

    switch (sortBy) {
      case 'newest':
        result = result.filter((p) => p.isNew).concat(result.filter((p) => !p.isNew))
        break
      case 'price-asc':
        result.sort((a, b) => a.price - b.price)
        break
      case 'price-desc':
        result.sort((a, b) => b.price - a.price)
        break
      case 'top-rated':
        result.sort((a, b) => b.rating - a.rating)
        break
    }

    return result
  }, [selectedCategory, selectedSizes, selectedColors, priceRange, sortBy, searchQuery])

  const activeFiltersCount =
    (selectedCategory !== 'all' ? 1 : 0) +
    selectedSizes.length +
    selectedColors.length

  const clearFilters = () => {
    setSelectedCategory('all')
    setSelectedSizes([])
    setSelectedColors([])
    setPriceRange([0, 100])
  }

  const FilterPanel = () => (
    <div className="space-y-0">
      <FilterSection title="Category">
        <div className="space-y-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.value}
              onClick={() => setSelectedCategory(cat.value)}
              className={`block w-full text-left text-sm px-3 py-2 rounded-lg transition-colors ${
                selectedCategory === cat.value
                  ? 'bg-black text-white dark:bg-white dark:text-black font-semibold'
                  : 'hover:bg-black/5 dark:hover:bg-white/5 text-black/70 dark:text-white/70'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </FilterSection>

      <FilterSection title="Size">
        <div className="flex flex-wrap gap-2">
          {SIZES.map((size) => (
            <button
              key={size}
              onClick={() => toggleSize(size)}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                selectedSizes.includes(size)
                  ? 'bg-black text-white dark:bg-white dark:text-black border-black dark:border-white'
                  : 'border-black/15 dark:border-white/15 hover:border-black dark:hover:border-white'
              }`}
            >
              {size}
            </button>
          ))}
        </div>
      </FilterSection>

      <FilterSection title="Color">
        <div className="flex flex-wrap gap-2">
          {COLORS.map((color) => (
            <button
              key={color}
              onClick={() => toggleColor(color)}
              className={`flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg border transition-colors ${
                selectedColors.includes(color)
                  ? 'border-black dark:border-white bg-black/5 dark:bg-white/5 font-semibold'
                  : 'border-black/15 dark:border-white/15 hover:border-black/40 dark:hover:border-white/40'
              }`}
            >
              <span
                className="w-3 h-3 rounded-full border border-black/10"
                style={{
                  background:
                    color === 'Black'
                      ? '#0a0a0a'
                      : color === 'White'
                        ? '#f5f5f5'
                        : color === 'Beige' || color === 'Cream'
                          ? '#f5f0eb'
                          : color === 'Stone'
                            ? '#d6d3d1'
                            : color === 'Charcoal'
                              ? '#555'
                              : color === 'Navy'
                                ? '#1e3a5f'
                                : '#ddd',
                }}
              />
              {color}
            </button>
          ))}
        </div>
      </FilterSection>

      <FilterSection title="Price Range">
        <div className="space-y-3">
          <input
            type="range"
            min={0}
            max={100}
            value={priceRange[1]}
            onChange={(e) => setPriceRange([0, +e.target.value])}
            className="w-full accent-black dark:accent-white"
          />
          <div className="flex justify-between text-xs text-black/50 dark:text-white/50">
            <span>$0</span>
            <span>Up to ${priceRange[1]}</span>
          </div>
        </div>
      </FilterSection>
    </div>
  )

  return (
    <div className="pt-20 lg:pt-24">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <h1
          className="text-4xl lg:text-5xl font-bold section-title mb-2"
        >
          Shop
        </h1>
        <p className="text-black/50 dark:text-white/50">
          Premium streetwear & minimal fashion for the new generation
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        {/* Toolbar */}
        <div className="flex items-center gap-4 mb-6">
          {/* Search */}
          <div className="relative flex-1 max-w-xs">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-black/30 dark:text-white/30" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2.5 text-sm bg-black/5 dark:bg-white/5 rounded-xl focus:outline-none"
            />
          </div>

          <button
            onClick={() => setFiltersOpen(!filtersOpen)}
            className={`lg:hidden flex items-center gap-2 px-4 py-2.5 text-sm font-medium rounded-xl border transition-colors ${
              filtersOpen || activeFiltersCount > 0
                ? 'bg-black text-white dark:bg-white dark:text-black border-transparent'
                : 'border-black/15 dark:border-white/15'
            }`}
          >
            <SlidersHorizontal size={15} />
            Filters
            {activeFiltersCount > 0 && (
              <span className="w-5 h-5 bg-white text-black dark:bg-black dark:text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {activeFiltersCount}
              </span>
            )}
          </button>

          <div className="ml-auto flex items-center gap-3">
            {activeFiltersCount > 0 && (
              <button
                onClick={clearFilters}
                className="flex items-center gap-1.5 text-sm text-black/50 dark:text-white/50 hover:text-black dark:hover:text-white transition-colors"
              >
                <X size={14} />
                Clear
              </button>
            )}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="text-sm bg-transparent border border-black/15 dark:border-white/15 rounded-xl px-3 py-2.5 focus:outline-none cursor-pointer"
            >
              {SORT_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex gap-8">
          {/* Sidebar filters (desktop) */}
          <aside className="hidden lg:block w-56 flex-shrink-0 sticky top-24 self-start">
            <FilterPanel />
          </aside>

          {/* Mobile filters drawer */}
          {filtersOpen && (
            <div className="lg:hidden fixed inset-0 z-50 flex">
              <div className="absolute inset-0 bg-black/40" onClick={() => setFiltersOpen(false)} />
              <div className="relative ml-auto w-80 bg-white dark:bg-black h-full overflow-y-auto p-6 shadow-2xl cart-drawer">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="font-semibold">Filters</h3>
                  <button onClick={() => setFiltersOpen(false)}>
                    <X size={20} />
                  </button>
                </div>
                <FilterPanel />
                <button
                  onClick={() => setFiltersOpen(false)}
                  className="w-full bg-black dark:bg-white text-white dark:text-black py-3 rounded-xl font-semibold text-sm mt-4"
                >
                  Show {filtered.length} Products
                </button>
              </div>
            </div>
          )}

          {/* Products grid */}
          <div className="flex-1">
            <p className="text-sm text-black/40 dark:text-white/40 mb-6">
              {filtered.length} product{filtered.length !== 1 ? 's' : ''}
            </p>
            {filtered.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-black/40 dark:text-white/40 text-lg mb-4">No products found</p>
                <button onClick={clearFilters} className="text-sm underline">
                  Clear filters
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-6">
                {filtered.map((p) => (
                  <ProductCard key={p.id} product={p} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
