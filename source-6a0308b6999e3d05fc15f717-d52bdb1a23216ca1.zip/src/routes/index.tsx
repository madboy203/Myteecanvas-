import { Link, createFileRoute } from '@tanstack/react-router'
import { ArrowRight, ChevronRight, Star, Truck, Shield, RotateCcw, Zap } from 'lucide-react'
import products from '@/data/products'
import { ProductCard } from '@/components/ProductCard'

export const Route = createFileRoute('/')({
  component: HomePage,
})

function HomePage() {
  const featured = products.filter((p) => p.isBestSeller).slice(0, 4)
  const trending = products.filter((p) => p.isTrending).slice(0, 4)
  const newArrivals = products.filter((p) => p.isNew).slice(0, 3)

  const reviews = [
    {
      name: 'Aryan K.',
      rating: 5,
      text: "The Shadow Drop Shoulder Tee is genuinely premium. Heavy, structured, and the oversized fit is *chef's kiss*.",
      avatar: 'AK',
      item: 'Shadow Drop Shoulder Tee',
    },
    {
      name: 'Zaid M.',
      rating: 5,
      text: 'Ordered 3 of the Blank Canvas Tees in different colors. Wears perfectly and holds shape after every wash.',
      avatar: 'ZM',
      item: 'Blank Canvas Tee',
    },
    {
      name: 'Riya S.',
      rating: 5,
      text: 'The Nocturne Hoodie is worth every penny. Heavyweight, cozy, and looks expensive. My whole uni noticed.',
      avatar: 'RS',
      item: 'Nocturne Oversized Hoodie',
    },
    {
      name: 'Fariz H.',
      rating: 5,
      text: 'Finally found a brand that gets the "minimal but premium" vibe. Void Polo is next level.',
      avatar: 'FH',
      item: 'Void Polo Shirt',
    },
    {
      name: 'Aiden C.',
      rating: 5,
      text: 'Fast shipping and the quality is insane for the price. Phantom Drop Shoulder is my daily go-to now.',
      avatar: 'AC',
      item: 'Phantom Drop Shoulder',
    },
  ]

  const instagramPosts = [
    'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&q=80',
    'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=400&q=80',
    'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80',
    'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=400&q=80',
    'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=400&q=80',
    'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=400&q=80',
  ]

  return (
    <div className="min-h-screen">
      {/* ── HERO ────────────────────────────────────────────── */}
      <section className="relative h-screen min-h-[600px] max-h-[900px] flex items-end pb-24 lg:pb-32 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=1600&q=85"
            alt="Hero"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/10" />
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <p className="text-white/50 text-xs font-semibold tracking-[0.3em] uppercase mb-4">
              New Collection 2025
            </p>
            <h1
              className="text-5xl sm:text-6xl lg:text-8xl font-bold text-white leading-[0.95] mb-6"
              style={{ fontFamily: 'var(--font-display)' }}
            >
              Wear
              <br />
              Confidence.
            </h1>
            <p className="text-white/60 text-lg sm:text-xl mb-10 max-w-md leading-relaxed">
              Premium Drop Shoulder & Streetwear Collection.
            </p>
            <div className="flex items-center gap-4 flex-wrap">
              <Link
                to="/shop"
                className="btn-magnetic inline-flex items-center gap-2 bg-white text-black px-8 py-4 rounded-full font-semibold text-sm hover:bg-white/90 transition-colors"
              >
                Shop Now
                <ArrowRight size={16} />
              </Link>
              <Link
                to="/shop"
                className="btn-magnetic inline-flex items-center gap-2 border border-white/30 text-white px-8 py-4 rounded-full font-semibold text-sm hover:bg-white/10 transition-colors"
              >
                Explore Collection
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/40 animate-float">
          <span className="text-xs tracking-widest uppercase">Scroll</span>
          <div className="w-px h-8 bg-white/20" />
        </div>
      </section>

      {/* ── MARQUEE BAND ────────────────────────────────────── */}
      <div className="bg-black text-white py-4 overflow-hidden">
        <div className="marquee-track animate-marquee">
          {[...Array(3)].map((_, i) => (
            <span key={i} className="inline-flex items-center gap-8 px-4">
              <span className="text-xs font-semibold tracking-[0.2em] uppercase">Premium Quality</span>
              <span className="text-white/30">✦</span>
              <span className="text-xs font-semibold tracking-[0.2em] uppercase">Free Shipping</span>
              <span className="text-white/30">✦</span>
              <span className="text-xs font-semibold tracking-[0.2em] uppercase">Drop Shoulder Specialists</span>
              <span className="text-white/30">✦</span>
              <span className="text-xs font-semibold tracking-[0.2em] uppercase">Minimal Streetwear</span>
              <span className="text-white/30">✦</span>
              <span className="text-xs font-semibold tracking-[0.2em] uppercase">Gen-Z Fashion</span>
              <span className="text-white/30">✦</span>
            </span>
          ))}
        </div>
      </div>

      {/* ── TRUST BADGES ────────────────────────────────────── */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
          {[
            { icon: <Truck size={20} />, title: 'Free Delivery', sub: 'On orders over $50' },
            { icon: <Shield size={20} />, title: 'Secure Checkout', sub: '100% protected' },
            { icon: <RotateCcw size={20} />, title: 'Easy Returns', sub: '14-day policy' },
            { icon: <Zap size={20} />, title: 'Fast Dispatch', sub: '24–48 hour processing' },
          ].map((b) => (
            <div
              key={b.title}
              className="trust-badge flex items-center gap-4 p-5 rounded-2xl cursor-default"
            >
              <div className="flex-shrink-0">{b.icon}</div>
              <div>
                <p className="text-sm font-semibold">{b.title}</p>
                <p className="text-xs text-black/40 dark:text-white/40">{b.sub}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ── FEATURED / BEST SELLERS ─────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-2">
              Community Approved
            </p>
            <h2
              className="text-3xl lg:text-4xl font-bold section-title"
            >
              Best Sellers
            </h2>
          </div>
          <Link
            to="/shop"
            className="hidden sm:flex items-center gap-1 text-sm font-medium text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors"
          >
            View All <ChevronRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {featured.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* ── SPLIT BANNER ────────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid lg:grid-cols-2 gap-4">
          <Link
            to="/shop"
            className="relative rounded-3xl overflow-hidden aspect-[4/3] group img-zoom-container block"
          >
            <img
              src="https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=800&q=80"
              alt="Oversized Collection"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-8">
              <div>
                <p className="text-white/60 text-xs font-semibold tracking-widest uppercase mb-2">
                  New Drop
                </p>
                <h3 className="text-white text-3xl font-bold section-title mb-4">
                  Oversized<br />Collection
                </h3>
                <span className="inline-flex items-center gap-2 bg-white text-black text-xs font-semibold px-5 py-2.5 rounded-full group-hover:bg-white/90 transition-colors">
                  Shop Now <ArrowRight size={14} />
                </span>
              </div>
            </div>
          </Link>
          <Link
            to="/shop"
            className="relative rounded-3xl overflow-hidden aspect-[4/3] group img-zoom-container block"
          >
            <img
              src="https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800&q=80"
              alt="Polo Collection"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-8">
              <div>
                <p className="text-white/60 text-xs font-semibold tracking-widest uppercase mb-2">
                  Essentials
                </p>
                <h3 className="text-white text-3xl font-bold section-title mb-4">
                  Polo &<br />Minimal
                </h3>
                <span className="inline-flex items-center gap-2 bg-white text-black text-xs font-semibold px-5 py-2.5 rounded-full group-hover:bg-white/90 transition-colors">
                  Explore <ArrowRight size={14} />
                </span>
              </div>
            </div>
          </Link>
        </div>
      </section>

      {/* ── TRENDING ────────────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-2">
              What's Hot
            </p>
            <h2 className="text-3xl lg:text-4xl font-bold section-title">
              Trending Now
            </h2>
          </div>
          <Link
            to="/shop"
            className="hidden sm:flex items-center gap-1 text-sm font-medium text-black/60 dark:text-white/60 hover:text-black dark:hover:text-white transition-colors"
          >
            View All <ChevronRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
          {trending.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* ── LIMITED EDITION BANNER ──────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="relative rounded-3xl overflow-hidden bg-black text-white">
          <div className="absolute inset-0">
            <img
              src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=1200&q=80"
              alt="Limited Edition"
              className="w-full h-full object-cover opacity-30"
            />
          </div>
          <div className="relative z-10 px-8 py-16 lg:px-16 lg:py-20 text-center">
            <span className="inline-block bg-amber-500 text-white text-xs font-bold tracking-widest uppercase px-4 py-1.5 rounded-full mb-6">
              Limited Edition
            </span>
            <h2
              className="text-4xl lg:text-6xl font-bold section-title mb-4 max-w-2xl mx-auto leading-tight"
            >
              Nocturne Collection
            </h2>
            <p className="text-white/60 mb-8 max-w-lg mx-auto">
              Only 50 pieces made. Heavyweight fleece. Premium construction. Once they're gone, they're gone.
            </p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-white text-black px-8 py-4 rounded-full font-semibold text-sm hover:bg-white/90 transition-colors btn-magnetic"
            >
              Shop Limited Edition
              <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* ── NEW ARRIVALS ─────────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-2">
              Just Dropped
            </p>
            <h2 className="text-3xl lg:text-4xl font-bold section-title">
              New Arrivals
            </h2>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6">
          {newArrivals.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      </section>

      {/* ── WHY CHOOSE US ────────────────────────────────────── */}
      <section className="bg-[#f5f0eb] dark:bg-black/40 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-3">
              The MTC Difference
            </p>
            <h2 className="text-3xl lg:text-4xl font-bold section-title">
              Why Choose Us
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                num: '280+',
                title: 'GSM Fabric',
                desc: 'Heavyweight ringspun cotton that feels premium and holds its shape.',
              },
              {
                num: '3K+',
                title: 'Happy Customers',
                desc: 'University students and young adults who choose quality over fast fashion.',
              },
              {
                num: '48h',
                title: 'Dispatch Time',
                desc: 'Orders picked, packed, and shipped within 48 hours of placement.',
              },
              {
                num: '100%',
                title: 'Satisfaction',
                desc: 'Love your order or we\'ll make it right — no questions asked.',
              },
            ].map((item) => (
              <div key={item.title} className="text-center">
                <p
                  className="text-4xl lg:text-5xl font-black mb-3 section-title"
                >
                  {item.num}
                </p>
                <h3 className="font-semibold mb-2">{item.title}</h3>
                <p className="text-sm text-black/50 dark:text-white/50 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CUSTOM DESIGN CTA ────────────────────────────────── */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-4">
              Your Brand, Your Canvas
            </p>
            <h2 className="text-4xl lg:text-5xl font-bold section-title leading-tight mb-6">
              Design Your<br />Own Apparel
            </h2>
            <p className="text-black/60 dark:text-white/60 leading-relaxed mb-8">
              Upload your logo, artwork, or prompt our AI to generate a design. We print it on premium streetwear — oversized tees, polos, hoodies, and more.
            </p>
            <div className="flex items-center gap-4">
              <Link
                to="/custom-design"
                className="btn-magnetic inline-flex items-center gap-2 bg-black dark:bg-white text-white dark:text-black px-8 py-4 rounded-full font-semibold text-sm hover:opacity-90 transition-opacity"
              >
                Start Designing
                <ArrowRight size={16} />
              </Link>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-square rounded-3xl overflow-hidden img-zoom-container">
              <img
                src="https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=700&q=80"
                alt="Custom Design"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 bg-white dark:bg-black border border-black/10 dark:border-white/10 rounded-2xl p-4 shadow-xl">
              <p className="text-xs font-semibold tracking-wide uppercase text-black/40 dark:text-white/40">AI-Powered</p>
              <p className="font-semibold text-sm mt-1">Generate any design with a prompt</p>
            </div>
          </div>
        </div>
      </section>

      {/* ── REVIEWS ──────────────────────────────────────────── */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-xs font-semibold tracking-[0.2em] text-white/40 uppercase mb-3">
              Real People, Real Fits
            </p>
            <h2 className="text-3xl lg:text-4xl font-bold section-title">
              What They're Saying
            </h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.slice(0, 3).map((r) => (
              <div
                key={r.name}
                className="bg-white/5 border border-white/10 rounded-2xl p-6 hover:bg-white/8 transition-colors"
              >
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(r.rating)].map((_, i) => (
                    <Star key={i} size={12} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-white/70 text-sm leading-relaxed mb-4">"{r.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center text-xs font-bold">
                    {r.avatar}
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{r.name}</p>
                    <p className="text-xs text-white/40">{r.item}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── INSTAGRAM GALLERY ────────────────────────────────── */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-8 text-center">
          <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-3">
            Follow @MyTeeCanvas
          </p>
          <h2 className="text-3xl font-bold section-title">
            #WearMyTeeCanvas
          </h2>
        </div>
        <div className="grid grid-cols-3 lg:grid-cols-6 gap-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {instagramPosts.map((src, i) => (
            <a
              key={i}
              href="#"
              className="aspect-square overflow-hidden group relative img-zoom-container"
            >
              <img
                src={src}
                alt={`Gallery ${i + 1}`}
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/30 transition-colors flex items-center justify-center">
                <span className="text-white opacity-0 group-hover:opacity-100 transition-opacity text-xs font-semibold">
                  View
                </span>
              </div>
            </a>
          ))}
        </div>
      </section>
    </div>
  )
}
