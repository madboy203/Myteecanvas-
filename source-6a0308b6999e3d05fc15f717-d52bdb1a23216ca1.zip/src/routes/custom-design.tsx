import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Upload, Wand2, MessageCircle, ChevronDown, Check, Sparkles, Phone } from 'lucide-react'

export const Route = createFileRoute('/custom-design')({
  component: CustomDesignPage,
})

const APPAREL_TYPES = [
  { id: 'oversized', label: 'Oversized Tee', icon: '👕', price: 35 },
  { id: 'polo', label: 'Polo Shirt', icon: '🎽', price: 42 },
  { id: 'basic-tee', label: 'Basic Tee', icon: '👚', price: 28 },
  { id: 'hoodie', label: 'Hoodie', icon: '🧥', price: 65 },
]

const PLACEMENTS = ['Front Print', 'Back Print', 'Sleeve Print', 'Chest Left', 'All Over']
const FABRICS = ['100% Cotton 280 GSM', '100% Cotton 300 GSM', 'Cotton/Poly Blend 260 GSM', 'Premium Fleece 380 GSM']
const COLORS = ['Black', 'White', 'Stone', 'Beige', 'Charcoal', 'Navy', 'Sage']
const SIZES_QTY = ['XS', 'S', 'M', 'L', 'XL', 'XXL']

const AI_PROMPTS = [
  'Minimal anime streetwear design',
  'Vintage racing aesthetic',
  'Korean oversized fashion print',
  'Abstract geometric waves',
  'Japanese typography art',
  'Grunge distressed logo',
]

const PORTFOLIO = [
  {
    img: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&q=80',
    label: 'Custom Band Merch',
    client: '@bandname',
  },
  {
    img: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=400&q=80',
    label: 'Minimalist Logo Drop',
    client: '@studiobrand',
  },
  {
    img: 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=400&q=80',
    label: 'Event Hoodie Pack',
    client: '@university_fest',
  },
  {
    img: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&q=80',
    label: 'Streetwear Brand Launch',
    client: '@newstreet_co',
  },
]

function CustomDesignPage() {
  const [selectedApparel, setSelectedApparel] = useState('oversized')
  const [selectedColor, setSelectedColor] = useState('Black')
  const [selectedPlacement, setSelectedPlacement] = useState('Front Print')
  const [selectedFabric, setSelectedFabric] = useState(FABRICS[0])
  const [quantity, setQuantity] = useState(10)
  const [urgentDelivery, setUrgentDelivery] = useState(false)
  const [aiPrompt, setAiPrompt] = useState('')
  const [designNotes, setDesignNotes] = useState('')
  const [dragOver, setDragOver] = useState(false)
  const [uploadedFile, setUploadedFile] = useState<string | null>(null)
  const [aiGenerating, setAiGenerating] = useState(false)
  const [aiGenerated, setAiGenerated] = useState(false)

  const selectedApparelData = APPAREL_TYPES.find((a) => a.id === selectedApparel)
  const basePrice = selectedApparelData?.price ?? 35
  const urgentAddon = urgentDelivery ? 8 : 0
  const bulkDiscount = quantity >= 50 ? 0.85 : quantity >= 20 ? 0.9 : 1
  const totalPrice = Math.round(basePrice * quantity * bulkDiscount + urgentAddon)

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)
    const file = e.dataTransfer.files[0]
    if (file) setUploadedFile(file.name)
  }

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) setUploadedFile(file.name)
  }

  const handleAiGenerate = () => {
    if (!aiPrompt) return
    setAiGenerating(true)
    setTimeout(() => {
      setAiGenerating(false)
      setAiGenerated(true)
    }, 2500)
  }

  return (
    <div className="pt-20 lg:pt-24">
      {/* Header */}
      <section className="relative overflow-hidden bg-black text-white py-20 lg:py-28">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=1200&q=80"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-xs font-semibold tracking-[0.3em] text-white/40 uppercase mb-4">
            Your brand, your canvas
          </p>
          <h1
            className="text-4xl sm:text-5xl lg:text-7xl font-bold section-title leading-tight mb-6"
          >
            Design Your<br />Own Apparel
          </h1>
          <p className="text-white/60 text-lg max-w-xl">
            Upload your design or let AI generate one. We print it on premium drop shoulder tees, polos, hoodies, and more.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-10">
          {/* ── Left: Config ──────────────────────── */}
          <div className="lg:col-span-2 space-y-10">
            {/* Step 1: Apparel type */}
            <section>
              <h2 className="text-xl font-bold mb-5 flex items-center gap-2">
                <span className="w-7 h-7 bg-black dark:bg-white text-white dark:text-black text-sm font-bold rounded-full flex items-center justify-center">1</span>
                Choose Apparel
              </h2>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {APPAREL_TYPES.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => setSelectedApparel(a.id)}
                    className={`p-4 rounded-2xl border-2 text-center transition-all ${
                      selectedApparel === a.id
                        ? 'border-black dark:border-white bg-black/5 dark:bg-white/5'
                        : 'border-black/10 dark:border-white/10 hover:border-black/30 dark:hover:border-white/30'
                    }`}
                  >
                    <div className="text-3xl mb-2">{a.icon}</div>
                    <p className="text-sm font-semibold">{a.label}</p>
                    <p className="text-xs text-black/40 dark:text-white/40 mt-0.5">from ${a.price}</p>
                  </button>
                ))}
              </div>
            </section>

            {/* Step 2: Upload design */}
            <section>
              <h2 className="text-xl font-bold mb-5 flex items-center gap-2">
                <span className="w-7 h-7 bg-black dark:bg-white text-white dark:text-black text-sm font-bold rounded-full flex items-center justify-center">2</span>
                Upload Your Design
              </h2>
              <div
                onDragOver={(e) => { e.preventDefault(); setDragOver(true) }}
                onDragLeave={() => setDragOver(false)}
                onDrop={handleDrop}
                className={`relative border-2 border-dashed rounded-2xl p-10 text-center transition-colors cursor-pointer ${
                  dragOver
                    ? 'border-black dark:border-white bg-black/5 dark:bg-white/5'
                    : uploadedFile
                      ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                      : 'border-black/15 dark:border-white/15 hover:border-black/40 dark:hover:border-white/40'
                }`}
              >
                <input
                  type="file"
                  accept=".png,.jpg,.jpeg,.pdf,.ai,.psd"
                  onChange={handleFileInput}
                  className="absolute inset-0 opacity-0 cursor-pointer"
                />
                {uploadedFile ? (
                  <div className="flex items-center justify-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center">
                      <Check size={20} className="text-green-600" />
                    </div>
                    <div className="text-left">
                      <p className="font-semibold text-green-700 dark:text-green-400">File uploaded!</p>
                      <p className="text-sm text-black/50 dark:text-white/50">{uploadedFile}</p>
                    </div>
                  </div>
                ) : (
                  <>
                    <Upload size={32} className="mx-auto mb-3 text-black/30 dark:text-white/30" />
                    <p className="font-semibold mb-1">Drag & drop your design here</p>
                    <p className="text-sm text-black/40 dark:text-white/40 mb-3">or click to browse</p>
                    <p className="text-xs text-black/30 dark:text-white/30">Supports: PNG, JPG, PDF, AI, PSD</p>
                  </>
                )}
              </div>
            </section>

            {/* Step 3: AI Design */}
            <section>
              <h2 className="text-xl font-bold mb-5 flex items-center gap-2">
                <span className="w-7 h-7 bg-black dark:bg-white text-white dark:text-black text-sm font-bold rounded-full flex items-center justify-center">3</span>
                <Wand2 size={18} />
                AI Design Generator
                <span className="bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-400 text-[10px] font-bold px-2 py-0.5 rounded-full">BETA</span>
              </h2>
              <div className="bg-[#f5f0eb] dark:bg-white/5 rounded-2xl p-6">
                <p className="text-sm text-black/60 dark:text-white/60 mb-4">
                  Describe your design idea and our AI will generate a sample mockup for you.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  {AI_PROMPTS.map((prompt) => (
                    <button
                      key={prompt}
                      onClick={() => setAiPrompt(prompt)}
                      className="text-xs px-3 py-1.5 bg-white dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-full hover:border-black dark:hover:border-white transition-colors"
                    >
                      {prompt}
                    </button>
                  ))}
                </div>
                <div className="flex gap-3">
                  <input
                    type="text"
                    placeholder="Describe your design... e.g. 'minimal anime streetwear'"
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="flex-1 px-4 py-3 text-sm bg-white dark:bg-black border border-black/10 dark:border-white/10 rounded-xl focus:outline-none focus:border-black dark:focus:border-white transition-colors"
                  />
                  <button
                    onClick={handleAiGenerate}
                    disabled={!aiPrompt || aiGenerating}
                    className="px-5 py-3 bg-black dark:bg-white text-white dark:text-black text-sm font-semibold rounded-xl disabled:opacity-50 flex items-center gap-2 transition-opacity hover:opacity-80"
                  >
                    {aiGenerating ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        Generating...
                      </>
                    ) : (
                      <>
                        <Sparkles size={15} />
                        Generate
                      </>
                    )}
                  </button>
                </div>
                {aiGenerated && (
                  <div className="mt-4 p-4 bg-white dark:bg-black/60 rounded-xl border border-black/8 dark:border-white/8 animate-scale-in">
                    <div className="flex items-center gap-2 mb-2">
                      <Check size={16} className="text-green-500" />
                      <p className="text-sm font-semibold">Design generated!</p>
                    </div>
                    <p className="text-xs text-black/50 dark:text-white/50">
                      Our designer will review your AI-generated concept and prepare a mockup within 24 hours. You'll receive an approval preview before printing.
                    </p>
                  </div>
                )}
              </div>
            </section>

            {/* Step 4: Customisation options */}
            <section>
              <h2 className="text-xl font-bold mb-5 flex items-center gap-2">
                <span className="w-7 h-7 bg-black dark:bg-white text-white dark:text-black text-sm font-bold rounded-full flex items-center justify-center">4</span>
                Customise
              </h2>
              <div className="grid sm:grid-cols-2 gap-6">
                {/* Color */}
                <div>
                  <p className="text-sm font-semibold mb-3">Apparel Color</p>
                  <div className="flex flex-wrap gap-2">
                    {COLORS.map((c) => (
                      <button
                        key={c}
                        onClick={() => setSelectedColor(c)}
                        title={c}
                        className={`w-8 h-8 rounded-full border-2 transition-all ${
                          selectedColor === c ? 'border-black dark:border-white scale-110' : 'border-transparent hover:scale-105'
                        }`}
                        style={{
                          background:
                            c === 'Black' ? '#0a0a0a' :
                            c === 'White' ? '#f5f5f5' :
                            c === 'Beige' ? '#f5f0eb' :
                            c === 'Stone' ? '#d6d3d1' :
                            c === 'Charcoal' ? '#555' :
                            c === 'Navy' ? '#1e3a5f' :
                            c === 'Sage' ? '#8fae99' : '#ddd',
                        }}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-black/40 dark:text-white/40 mt-2">{selectedColor}</p>
                </div>

                {/* Print placement */}
                <div>
                  <p className="text-sm font-semibold mb-3">Print Placement</p>
                  <div className="flex flex-wrap gap-2">
                    {PLACEMENTS.map((p) => (
                      <button
                        key={p}
                        onClick={() => setSelectedPlacement(p)}
                        className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${
                          selectedPlacement === p
                            ? 'bg-black text-white dark:bg-white dark:text-black border-black dark:border-white'
                            : 'border-black/15 dark:border-white/15 hover:border-black dark:hover:border-white'
                        }`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Fabric */}
                <div>
                  <p className="text-sm font-semibold mb-3">Fabric</p>
                  <select
                    value={selectedFabric}
                    onChange={(e) => setSelectedFabric(e.target.value)}
                    className="w-full text-sm bg-transparent border border-black/15 dark:border-white/15 rounded-xl px-3 py-2.5 focus:outline-none focus:border-black dark:focus:border-white"
                  >
                    {FABRICS.map((f) => (
                      <option key={f} value={f}>{f}</option>
                    ))}
                  </select>
                </div>

                {/* Size breakdown */}
                <div>
                  <p className="text-sm font-semibold mb-3">Sizes Needed</p>
                  <div className="flex flex-wrap gap-2">
                    {SIZES_QTY.map((s) => (
                      <span
                        key={s}
                        className="text-xs px-3 py-1.5 rounded-lg border border-black/15 dark:border-white/15 text-black/60 dark:text-white/60"
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                  <p className="text-xs text-black/40 dark:text-white/40 mt-2">Contact designer for size breakdown</p>
                </div>
              </div>

              {/* Design notes */}
              <div className="mt-6">
                <p className="text-sm font-semibold mb-3">Design Notes</p>
                <textarea
                  rows={3}
                  placeholder="Any specific requirements, colour codes, fonts, placement notes, or revision requests..."
                  value={designNotes}
                  onChange={(e) => setDesignNotes(e.target.value)}
                  className="w-full text-sm bg-transparent border border-black/15 dark:border-white/15 rounded-xl px-4 py-3 focus:outline-none focus:border-black dark:focus:border-white transition-colors resize-none"
                />
              </div>
            </section>
          </div>

          {/* ── Right: Summary ────────────────────── */}
          <div>
            <div className="sticky top-24 space-y-4">
              {/* Order summary */}
              <div className="rounded-2xl border border-black/10 dark:border-white/10 p-6">
                <h3 className="font-bold text-lg mb-5">Order Summary</h3>

                {/* Mockup preview */}
                <div className="aspect-square rounded-2xl overflow-hidden bg-[#f5f0eb] mb-5 flex items-center justify-center text-6xl">
                  {selectedApparelData?.icon}
                  <div
                    className="absolute w-8 h-8 rounded opacity-50 flex items-center justify-center text-[10px]"
                    style={{
                      background: selectedColor === 'Black' ? '#0a0a0a' : selectedColor === 'White' ? '#ddd' : '#f5f0eb',
                    }}
                  />
                </div>

                <div className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-black/50 dark:text-white/50">Apparel</span>
                    <span className="font-medium">{selectedApparelData?.label}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-black/50 dark:text-white/50">Color</span>
                    <span className="font-medium">{selectedColor}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-black/50 dark:text-white/50">Placement</span>
                    <span className="font-medium">{selectedPlacement}</span>
                  </div>

                  {/* Quantity */}
                  <div className="border-t border-black/8 dark:border-white/8 pt-3">
                    <p className="text-black/50 dark:text-white/50 mb-2">Quantity</p>
                    <div className="flex items-center gap-2">
                      {[5, 10, 20, 50, 100].map((q) => (
                        <button
                          key={q}
                          onClick={() => setQuantity(q)}
                          className={`text-xs px-2.5 py-1.5 rounded-lg border transition-colors ${
                            quantity === q
                              ? 'bg-black text-white dark:bg-white dark:text-black border-black dark:border-white'
                              : 'border-black/15 dark:border-white/15'
                          }`}
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                    {quantity >= 20 && (
                      <p className="text-xs text-green-600 mt-1.5">
                        {quantity >= 50 ? '15% bulk discount applied!' : '10% bulk discount applied!'}
                      </p>
                    )}
                  </div>

                  {/* Urgent delivery */}
                  <div className="border-t border-black/8 dark:border-white/8 pt-3">
                    <label className="flex items-center gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={urgentDelivery}
                        onChange={(e) => setUrgentDelivery(e.target.checked)}
                        className="w-4 h-4 accent-black dark:accent-white"
                      />
                      <div>
                        <p className="text-sm font-medium">Urgent Delivery +$8</p>
                        <p className="text-xs text-black/40 dark:text-white/40">5–7 days instead of 10–14</p>
                      </div>
                    </label>
                  </div>

                  {/* Pricing */}
                  <div className="border-t border-black/8 dark:border-white/8 pt-3 space-y-1">
                    <div className="flex justify-between text-xs text-black/50 dark:text-white/50">
                      <span>Unit price</span>
                      <span>${(basePrice * bulkDiscount).toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-xs text-black/50 dark:text-white/50">
                      <span>Quantity</span>
                      <span>×{quantity}</span>
                    </div>
                    {urgentDelivery && (
                      <div className="flex justify-between text-xs text-black/50 dark:text-white/50">
                        <span>Urgent delivery</span>
                        <span>$8</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-base pt-1">
                      <span>Total</span>
                      <span>${totalPrice}</span>
                    </div>
                  </div>
                </div>

                <button className="w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-xl font-semibold text-sm mt-5 hover:opacity-90 transition-opacity">
                  Submit Custom Order
                </button>
                <p className="text-xs text-black/30 dark:text-white/30 text-center mt-3">
                  You'll receive a design approval before production
                </p>
              </div>

              {/* Delivery estimate */}
              <div className="rounded-2xl bg-[#f5f0eb] dark:bg-white/5 p-4">
                <p className="text-sm font-semibold mb-1">Estimated Delivery</p>
                <p className="text-xs text-black/50 dark:text-white/50">
                  {urgentDelivery ? '5–7 working days' : '10–14 working days'} after design approval
                </p>
              </div>

              {/* Designer contact */}
              <div className="rounded-2xl border border-black/10 dark:border-white/10 p-5">
                <p className="text-sm font-semibold mb-3">Talk to a Designer</p>
                <p className="text-xs text-black/50 dark:text-white/50 mb-4">
                  Need help with your design? Our team is ready to assist.
                </p>
                <div className="space-y-2">
                  <a
                    href="https://wa.me/1234567890"
                    className="flex items-center gap-3 text-sm py-2.5 px-4 bg-green-500 text-white rounded-xl hover:bg-green-600 transition-colors"
                  >
                    <Phone size={14} />
                    WhatsApp Chat
                  </a>
                  <a
                    href="https://m.me/myteecanvas"
                    className="flex items-center gap-3 text-sm py-2.5 px-4 bg-blue-500 text-white rounded-xl hover:bg-blue-600 transition-colors"
                  >
                    <MessageCircle size={14} />
                    Messenger
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Portfolio ─────────────────────────────────────────── */}
      <section className="bg-[#f5f0eb] dark:bg-black/40 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-3">
              Previous Work
            </p>
            <h2 className="text-3xl font-bold section-title">
              Customer Designs
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {PORTFOLIO.map((item) => (
              <div
                key={item.label}
                className="rounded-2xl overflow-hidden group relative img-zoom-container"
              >
                <div className="aspect-square">
                  <img
                    src={item.img}
                    alt={item.label}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/60 transition-colors flex items-end p-4">
                  <div className="translate-y-2 group-hover:translate-y-0 opacity-0 group-hover:opacity-100 transition-all">
                    <p className="text-white text-sm font-semibold">{item.label}</p>
                    <p className="text-white/60 text-xs">{item.client}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}
