import { HeadContent, Outlet, Scripts, createRootRoute } from '@tanstack/react-router'
import { CartProvider } from '@/context/CartContext'
import { WishlistProvider } from '@/context/WishlistContext'
import { Navbar } from '@/components/Navbar'
import { Footer } from '@/components/Footer'
import { CartDrawer } from '@/components/CartDrawer'
import '../styles.css'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'MyTeeCanvas — Premium Drop Shoulder & Streetwear' },
      {
        name: 'description',
        content:
          'Premium oversized drop shoulder t-shirts, polos, streetwear and minimal fashion for the new generation.',
      },
      { name: 'theme-color', content: '#0a0a0a' },
    ],
    links: [
      { rel: 'preconnect', href: 'https://fonts.googleapis.com' },
      { rel: 'preconnect', href: 'https://fonts.gstatic.com', crossOrigin: 'anonymous' },
      {
        rel: 'stylesheet',
        href: 'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&family=Playfair+Display:wght@400;500;600;700&display=swap',
      },
    ],
  }),
  shellComponent: RootDocument,
})

function RootDocument({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <CartProvider>
          <WishlistProvider>
            <Navbar />
            <CartDrawer />
            {children}
            <Footer />
          </WishlistProvider>
        </CartProvider>
        <Scripts />
      </body>
    </html>
  )
}
