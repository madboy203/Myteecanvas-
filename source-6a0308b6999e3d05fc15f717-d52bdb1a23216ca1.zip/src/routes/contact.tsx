import { createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import { Mail, Phone, MapPin, MessageCircle, ChevronDown, ChevronUp, Send, Check } from 'lucide-react'

export const Route = createFileRoute('/contact')({
  component: ContactPage,
})

const FAQ = [
  {
    q: 'How long does shipping take?',
    a: 'Standard orders ship within 48 hours and arrive in 5–7 working days. Express options deliver in 2–3 days.',
  },
  {
    q: 'What sizes do you offer?',
    a: 'We stock XS through XXL across all styles. Check the size chart on each product page for exact measurements.',
  },
  {
    q: 'Do you offer custom printing?',
    a: 'Yes! Visit our Custom Design page to upload your artwork, use AI-generated designs, and get a quote.',
  },
  {
    q: 'What is your return policy?',
    a: 'We accept returns within 14 days of delivery. Items must be unworn with original tags. Custom orders are non-refundable.',
  },
  {
    q: 'What fabric weight do you use?',
    a: 'Our drop shoulder tees start at 280 GSM and go up to 300 GSM. Our hoodies use 380 GSM fleece.',
  },
  {
    q: 'Do you ship internationally?',
    a: 'We currently ship to Malaysia, Singapore, UK, USA, and Australia. More countries coming soon.',
  },
  {
    q: 'Can I cancel or modify my order?',
    a: 'Contact us within 2 hours of placing your order. After that, orders enter processing and cannot be modified.',
  },
]

function FAQItem({ q, a }: { q: string; a: string }) {
  const [open, setOpen] = useState(false)
  return (
    <div className="border-b border-black/8 dark:border-white/8 py-4">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center justify-between w-full text-left gap-4"
      >
        <span className="font-medium text-sm">{q}</span>
        {open ? (
          <ChevronUp size={16} className="flex-shrink-0 text-black/40 dark:text-white/40" />
        ) : (
          <ChevronDown size={16} className="flex-shrink-0 text-black/40 dark:text-white/40" />
        )}
      </button>
      {open && (
        <p className="mt-3 text-sm text-black/60 dark:text-white/60 leading-relaxed animate-fade-in">
          {a}
        </p>
      )}
    </div>
  )
}

function ContactPage() {
  const [submitted, setSubmitted] = useState(false)
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setSubmitted(true)
  }

  return (
    <div className="pt-20 lg:pt-24">
      {/* Header */}
      <div className="bg-[#f5f0eb] dark:bg-black/40 py-16 lg:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-3">
            We're here to help
          </p>
          <h1 className="text-4xl lg:text-5xl font-bold section-title">Get in Touch</h1>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact options */}
          <div className="space-y-4">
            <h2 className="font-bold text-xl mb-6">Contact Options</h2>

            {[
              {
                icon: <Phone size={18} className="text-green-500" />,
                title: 'WhatsApp Chat',
                sub: 'Fastest response — reply in minutes',
                action: 'Chat Now',
                href: 'https://wa.me/1234567890',
                color: 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800',
              },
              {
                icon: <MessageCircle size={18} className="text-blue-500" />,
                title: 'Facebook Messenger',
                sub: 'Message us on Facebook',
                action: 'Open Messenger',
                href: 'https://m.me/myteecanvas',
                color: 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800',
              },
              {
                icon: <Mail size={18} />,
                title: 'Email Support',
                sub: 'hello@myteecanvas.com',
                action: 'Send Email',
                href: 'mailto:hello@myteecanvas.com',
                color: 'bg-black/3 dark:bg-white/5 border-black/10 dark:border-white/10',
              },
            ].map((c) => (
              <a
                key={c.title}
                href={c.href}
                className={`flex items-start gap-4 p-5 rounded-2xl border transition-transform hover:scale-[1.02] ${c.color}`}
              >
                <div className="mt-0.5">{c.icon}</div>
                <div className="flex-1">
                  <p className="font-semibold text-sm">{c.title}</p>
                  <p className="text-xs text-black/50 dark:text-white/50 mt-0.5">{c.sub}</p>
                </div>
                <span className="text-xs font-semibold text-black/40 dark:text-white/40 whitespace-nowrap">
                  {c.action} →
                </span>
              </a>
            ))}

            {/* Store info */}
            <div className="p-5 rounded-2xl border border-black/10 dark:border-white/10 mt-6">
              <div className="flex items-start gap-3 mb-4">
                <MapPin size={16} className="mt-0.5 text-black/40 dark:text-white/40" />
                <div>
                  <p className="text-sm font-semibold">Based in</p>
                  <p className="text-xs text-black/50 dark:text-white/50 mt-1">Kuala Lumpur, Malaysia</p>
                </div>
              </div>
              <div className="text-xs text-black/40 dark:text-white/40 space-y-1">
                <p>Mon–Fri: 9am – 6pm MYT</p>
                <p>Sat: 10am – 2pm MYT</p>
                <p>Sun: Closed</p>
              </div>
            </div>
          </div>

          {/* Contact form */}
          <div className="lg:col-span-2">
            <h2 className="font-bold text-xl mb-6">Send a Message</h2>

            {submitted ? (
              <div className="rounded-2xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 p-10 text-center animate-scale-in">
                <div className="w-14 h-14 rounded-full bg-green-500 text-white flex items-center justify-center mx-auto mb-4">
                  <Check size={24} />
                </div>
                <h3 className="font-bold text-xl mb-2">Message Sent!</h3>
                <p className="text-black/60 dark:text-white/60 text-sm">
                  We'll get back to you within 24 hours. For urgent queries, please use WhatsApp.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="grid sm:grid-cols-2 gap-5">
                  <div>
                    <label className="block text-sm font-medium mb-2">Name *</label>
                    <input
                      required
                      type="text"
                      placeholder="Your name"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="w-full px-4 py-3 text-sm border border-black/15 dark:border-white/15 rounded-xl bg-transparent focus:outline-none focus:border-black dark:focus:border-white transition-colors"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Email *</label>
                    <input
                      required
                      type="email"
                      placeholder="your@email.com"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="w-full px-4 py-3 text-sm border border-black/15 dark:border-white/15 rounded-xl bg-transparent focus:outline-none focus:border-black dark:focus:border-white transition-colors"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Subject</label>
                  <select
                    value={form.subject}
                    onChange={(e) => setForm({ ...form, subject: e.target.value })}
                    className="w-full px-4 py-3 text-sm border border-black/15 dark:border-white/15 rounded-xl bg-transparent focus:outline-none focus:border-black dark:focus:border-white transition-colors"
                  >
                    <option value="">Select a topic...</option>
                    <option>Order Inquiry</option>
                    <option>Custom Design Quote</option>
                    <option>Returns & Refunds</option>
                    <option>Product Question</option>
                    <option>Wholesale / Bulk Order</option>
                    <option>Other</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Message *</label>
                  <textarea
                    required
                    rows={5}
                    placeholder="Tell us how we can help..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="w-full px-4 py-3 text-sm border border-black/15 dark:border-white/15 rounded-xl bg-transparent focus:outline-none focus:border-black dark:focus:border-white transition-colors resize-none"
                  />
                </div>
                <button
                  type="submit"
                  className="flex items-center gap-2 bg-black dark:bg-white text-white dark:text-black px-8 py-4 rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity"
                >
                  <Send size={15} />
                  Send Message
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* FAQ */}
      <div className="bg-[#f5f0eb] dark:bg-black/40 py-20">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-3">
              Common Questions
            </p>
            <h2 className="text-3xl font-bold section-title">FAQ</h2>
          </div>
          <div>
            {FAQ.map((item) => (
              <FAQItem key={item.q} q={item.q} a={item.a} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
