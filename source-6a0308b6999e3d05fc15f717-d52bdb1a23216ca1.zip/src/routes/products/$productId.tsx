import { Link, createFileRoute } from '@tanstack/react-router'
import { useState } from 'react'
import {
  ShoppingBag,
  Heart,
  Star,
  Truck,
  RotateCcw,
  Shield,
  Minus,
  Plus,
  ChevronRight,
  ZoomIn,
  Share2,
} from 'lucide-react'
import products from '@/data/products'
import { ProductCard } from '@/components/ProductCard'
import { useCart } from '@/context/CartContext'
import { useWishlist } from '@/context/WishlistContext'

export const Route = createFileRoute('/products/$productId')({
  component: ProductDetailPage,
  loader: async ({ params }) => {
    const product = products.find((p) => p.id === +params.productId)
    if (!product) throw new Error('Product not found')
    return product
  },
})

function ProductDetailPage() {
  const product = Route.useLoaderData()
  const { addItem } = useCart()
  const { toggle, isWishlisted } = useWishlist()
  const wishlisted = isWishlisted(product.id)

  const [selectedSize, setSelectedSize] = useState(product.sizes[1] || product.sizes[0])
  const [selectedColor, setSelectedColor] = useState(product.colors[0])
  const [quantity, setQuantity] = useState(1)
  const [activeImage, setActiveImage] = useState(0)
  const [zoomed, setZoomed] = useState(false)
  const [added, setAdded] = useState(false)

  const related = products.filter(
    (p) => p.id !== product.id && (p.category === product.category || p.isBestSeller),
  ).slice(0, 4)

  const discount = product.originalPrice
    ? Math.round((1 - product.price / product.originalPrice) * 100)
    : 0

  const reviews = [
    {
      name: 'Marcus L.',
      rating: 5,
      date: 'May 2025',
      text: 'Absolutely love this piece. The fabric quality is exceptional for the price. Size M fits perfectly as an oversized tee. Will be ordering more colors.',
      size: 'M',
      color: product.colors[0],
      avatar: 'ML',
    },
    {
      name: 'Sofia R.',
      rating: 5,
      date: 'Apr 2025',
      text: 'The drop shoulders are so well done. Proper heavy gsm cotton, no see-through issues. This is my 3rd purchase from MTC.',
      size: 'S',
      color: product.colors[0],
      avatar: 'SR',
    },
    {
      name: 'Khalid A.',
      rating: 4,
      date: 'Apr 2025',
      text: 'Great product overall. Packaging is clean and premium. Delivery was fast. Fabric might shrink slightly so order one size up.',
      size: 'L',
      color: product.colors.length > 1 ? product.colors[1] : product.colors[0],
      avatar: 'KA',
    },
  ]

  const handleAddToCart = () => {
    addItem(product, selectedSize, selectedColor, quantity)
    setAdded(true)
    setTimeout(() => setAdded(false), 2000)
  }

  return (
    <div className="pt-20 lg:pt-24">
      {/* Breadcrumb */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center gap-2 text-xs text-black/40 dark:text-white/40">
          <Link to="/" className="hover:text-black dark:hover:text-white transition-colors">Home</Link>
          <ChevronRight size={12} />
          <Link to="/shop" className="hover:text-black dark:hover:text-white transition-colors">Shop</Link>
          <ChevronRight size={12} />
          <span className="text-black dark:text-white">{product.name}</span>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16">
          {/* ── Gallery ─────────────────────────────── */}
          <div className="space-y-3">
            {/* Main image */}
            <div
              className="relative aspect-[4/5] rounded-3xl overflow-hidden bg-[#f5f0eb] cursor-zoom-in"
              onClick={() => setZoomed(!zoomed)}
            >
              <img
                src={product.images[activeImage]}
                alt={product.name}
                className={`w-full h-full object-cover transition-transform duration-500 ${zoomed ? 'scale-150' : 'scale-100'}`}
              />
              <button className="absolute top-4 right-4 w-9 h-9 bg-white/80 rounded-full flex items-center justify-center text-black/60 hover:bg-white transition-colors">
                <ZoomIn size={16} />
              </button>
              {/* Badges */}
              <div className="absolute top-4 left-4 flex flex-col gap-1.5">
                {product.isNew && (
                  <span className="bg-black text-white text-[10px] font-semibold px-2.5 py-1 rounded-full">NEW</span>
                )}
                {product.isLimitedEdition && (
                  <span className="bg-amber-500 text-white text-[10px] font-semibold px-2.5 py-1 rounded-full">LIMITED</span>
                )}
                {discount > 0 && (
                  <span className="bg-red-500 text-white text-[10px] font-semibold px-2.5 py-1 rounded-full">-{discount}%</span>
                )}
              </div>
            </div>

            {/* Thumbnails */}
            {product.images.length > 1 && (
              <div className="flex gap-3">
                {product.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`w-20 h-24 rounded-xl overflow-hidden flex-shrink-0 border-2 transition-colors ${
                      activeImage === i ? 'border-black dark:border-white' : 'border-transparent'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ── Product Info ────────────────────────── */}
          <div>
            {/* Urgency signals */}
            <div className="flex items-center gap-4 mb-4">
              {product.stock <= 10 && (
                <span className="text-xs font-semibold text-red-500 bg-red-50 px-3 py-1 rounded-full">
                  Only {product.stock} left in stock
                </span>
              )}
              <span className="text-xs text-black/40 dark:text-white/40">
                {product.soldThisWeek}+ sold this week
              </span>
            </div>

            <h1
              className="text-3xl lg:text-4xl font-bold section-title leading-tight mb-3"
            >
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mb-5">
              <div className="flex items-center gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className={
                      i < Math.floor(product.rating)
                        ? 'fill-amber-400 text-amber-400'
                        : 'fill-none text-black/20'
                    }
                  />
                ))}
              </div>
              <span className="text-sm font-semibold">{product.rating}</span>
              <span className="text-sm text-black/40 dark:text-white/40">({product.reviewCount} reviews)</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-6">
              <span className="text-3xl font-black">${product.price}</span>
              {product.originalPrice && (
                <>
                  <span className="text-lg text-black/40 dark:text-white/40 line-through">${product.originalPrice}</span>
                  <span className="text-sm font-semibold text-red-500">Save {discount}%</span>
                </>
              )}
            </div>

            {/* Color selection */}
            <div className="mb-5">
              <p className="text-sm font-semibold mb-3">
                Color: <span className="font-normal text-black/50 dark:text-white/50">{selectedColor}</span>
              </p>
              <div className="flex items-center gap-2">
                {product.colors.map((color) => (
                  <button
                    key={color}
                    onClick={() => setSelectedColor(color)}
                    title={color}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${
                      selectedColor === color
                        ? 'border-black dark:border-white scale-110'
                        : 'border-black/10 dark:border-white/10 hover:scale-105'
                    }`}
                    style={{
                      background:
                        color === 'Black'
                          ? '#0a0a0a'
                          : color === 'White'
                            ? '#f5f5f5'
                            : color === 'Beige' || color === 'Cream'
                              ? '#f5f0eb'
                              : color === 'Stone'
                                ? '#d6d3d1'
                                : color === 'Charcoal' || color === 'Slate Grey'
                                  ? '#555'
                                  : color === 'Navy'
                                    ? '#1e3a5f'
                                    : '#ddd',
                    }}
                  />
                ))}
              </div>
            </div>

            {/* Size selection */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <p className="text-sm font-semibold">
                  Size: <span className="font-normal text-black/50 dark:text-white/50">{selectedSize}</span>
                </p>
                <button className="text-xs text-black/40 dark:text-white/40 underline hover:text-black dark:hover:text-white transition-colors">
                  Size Guide
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {product.sizes.map((size) => (
                  <button
                    key={size}
                    onClick={() => setSelectedSize(size)}
                    className={`px-4 py-2.5 text-sm font-semibold rounded-xl border transition-colors ${
                      selectedSize === size
                        ? 'bg-black text-white dark:bg-white dark:text-black border-black dark:border-white'
                        : 'border-black/15 dark:border-white/15 hover:border-black dark:hover:border-white'
                    }`}
                  >
                    {size}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity + CTA */}
            <div className="flex items-center gap-3 mb-5">
              <div className="flex items-center border border-black/15 dark:border-white/15 rounded-xl overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-11 h-12 flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                >
                  <Minus size={14} />
                </button>
                <span className="w-10 text-center text-sm font-semibold">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="w-11 h-12 flex items-center justify-center hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
                >
                  <Plus size={14} />
                </button>
              </div>

              <button
                onClick={handleAddToCart}
                className={`flex-1 py-3.5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2 transition-all ${
                  added
                    ? 'bg-green-600 text-white'
                    : 'bg-black dark:bg-white text-white dark:text-black hover:opacity-90'
                }`}
              >
                <ShoppingBag size={16} />
                {added ? 'Added to Cart!' : 'Add to Cart'}
              </button>

              <button
                onClick={() => toggle(product)}
                className={`w-12 h-12 rounded-xl border flex items-center justify-center transition-colors ${
                  wishlisted
                    ? 'bg-black text-white dark:bg-white dark:text-black border-black dark:border-white'
                    : 'border-black/15 dark:border-white/15 hover:border-black dark:hover:border-white'
                }`}
              >
                <Heart size={16} fill={wishlisted ? 'currentColor' : 'none'} />
              </button>
            </div>

            {/* Share */}
            <button className="flex items-center gap-1.5 text-xs text-black/40 dark:text-white/40 hover:text-black dark:hover:text-white transition-colors mb-8">
              <Share2 size={13} />
              Share this
            </button>

            {/* Delivery info */}
            <div className="space-y-3 border-t border-black/8 dark:border-white/8 pt-6">
              {[
                {
                  icon: <Truck size={15} />,
                  title: 'Free delivery on orders over $50',
                  sub: 'Standard: 5–7 days · Express: 2–3 days',
                },
                {
                  icon: <RotateCcw size={15} />,
                  title: 'Easy 14-day returns',
                  sub: 'Unworn with tags attached',
                },
                {
                  icon: <Shield size={15} />,
                  title: 'Secure payment',
                  sub: 'All major cards, COD available',
                },
              ].map((item) => (
                <div key={item.title} className="flex items-start gap-3">
                  <div className="mt-0.5 text-black/50 dark:text-white/50">{item.icon}</div>
                  <div>
                    <p className="text-sm font-medium">{item.title}</p>
                    <p className="text-xs text-black/40 dark:text-white/40">{item.sub}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* ── Product Details Tabs ─────────────────────────────── */}
        <div className="mt-16 border-t border-black/8 dark:border-white/8 pt-12">
          <div className="grid lg:grid-cols-3 gap-10">
            <div>
              <h3 className="font-semibold mb-3">Description</h3>
              <p className="text-sm text-black/60 dark:text-white/60 leading-relaxed">
                {product.description}
              </p>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Fabric & Care</h3>
              <p className="text-sm text-black/60 dark:text-white/60 mb-3">{product.fabric}</p>
              <ul className="text-sm text-black/60 dark:text-white/60 space-y-1.5">
                <li>• Machine wash cold, inside out</li>
                <li>• Do not bleach or dry clean</li>
                <li>• Tumble dry low or lay flat</li>
                <li>• Cool iron if needed</li>
              </ul>
            </div>
            <div>
              <h3 className="font-semibold mb-3">Size Chart</h3>
              <table className="text-xs w-full border-collapse">
                <thead>
                  <tr className="border-b border-black/8 dark:border-white/8">
                    <th className="text-left py-2 font-semibold">Size</th>
                    <th className="text-left py-2 font-semibold">Chest</th>
                    <th className="text-left py-2 font-semibold">Length</th>
                  </tr>
                </thead>
                <tbody className="text-black/50 dark:text-white/50">
                  {[
                    ['XS', '38"', '27"'],
                    ['S', '40"', '28"'],
                    ['M', '43"', '29"'],
                    ['L', '46"', '30"'],
                    ['XL', '49"', '31"'],
                    ['XXL', '52"', '32"'],
                  ].map(([size, chest, len]) => (
                    <tr key={size} className="border-b border-black/5 dark:border-white/5">
                      <td className="py-1.5">{size}</td>
                      <td className="py-1.5">{chest}</td>
                      <td className="py-1.5">{len}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* ── Reviews ─────────────────────────────────────────── */}
        <div className="mt-16 border-t border-black/8 dark:border-white/8 pt-12">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold section-title">
              Customer Reviews
            </h2>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className="fill-amber-400 text-amber-400" />
                ))}
              </div>
              <span className="font-bold">{product.rating}</span>
              <span className="text-black/40 dark:text-white/40 text-sm">({product.reviewCount})</span>
            </div>
          </div>
          <div className="grid lg:grid-cols-3 gap-6 mb-8">
            {reviews.map((r) => (
              <div key={r.name} className="p-5 rounded-2xl border border-black/8 dark:border-white/8">
                <div className="flex items-center gap-1 mb-2">
                  {[...Array(r.rating)].map((_, i) => (
                    <Star key={i} size={12} className="fill-amber-400 text-amber-400" />
                  ))}
                </div>
                <p className="text-sm text-black/70 dark:text-white/70 leading-relaxed mb-4">
                  "{r.text}"
                </p>
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-black/10 dark:bg-white/10 flex items-center justify-center text-[10px] font-bold">
                    {r.avatar}
                  </div>
                  <div>
                    <p className="text-xs font-semibold">{r.name}</p>
                    <p className="text-[10px] text-black/40 dark:text-white/40">
                      Size {r.size} · {r.color} · {r.date}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ── Related Products ─────────────────────────────────── */}
        <div className="mt-16 border-t border-black/8 dark:border-white/8 pt-12">
          <h2 className="text-2xl font-bold section-title mb-8">You May Also Like</h2>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
