import { createFileRoute } from '@tanstack/react-router'
import { ArrowRight } from 'lucide-react'
import { Link } from '@tanstack/react-router'

export const Route = createFileRoute('/about')({
  component: AboutPage,
})

function AboutPage() {
  const values = [
    {
      title: 'Premium Quality',
      desc: "Every piece is made from heavyweight ringspun cotton. We don't do flimsy. If it doesn't feel expensive, it doesn't ship.",
    },
    {
      title: 'Minimal Aesthetic',
      desc: 'Inspired by Uniqlo, Represent, and Korean streetwear. Clean lines, intentional design, nothing unnecessary.',
    },
    {
      title: 'Accessible Luxury',
      desc: "Premium streetwear shouldn't cost a month's rent. We make quality accessible to students and young adults.",
    },
    {
      title: 'Community First',
      desc: 'Our designs are shaped by the streets, the campus, and the culture — not boardrooms or trend reports.',
    },
  ]

  const team = [
    {
      name: 'Adam R.',
      role: 'Founder & Creative Director',
      img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&q=80',
    },
    {
      name: 'Priya K.',
      role: 'Head of Design',
      img: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=300&q=80',
    },
    {
      name: 'Zain H.',
      role: 'Brand & Marketing',
      img: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&q=80',
    },
  ]

  return (
    <div className="pt-20 lg:pt-24">
      {/* Hero */}
      <section className="relative h-[60vh] min-h-[400px] flex items-end overflow-hidden">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=1400&q=80"
            alt="About"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16">
          <p className="text-white/50 text-xs font-semibold tracking-[0.3em] uppercase mb-4">Our Story</p>
          <h1
            className="text-5xl lg:text-7xl font-bold text-white section-title leading-tight"
          >
            Born from<br />the Streets.
          </h1>
        </div>
      </section>

      {/* Story */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-4">
              The Beginning
            </p>
            <h2 className="text-3xl lg:text-4xl font-bold section-title mb-6">
              We started with a problem
            </h2>
            <p className="text-black/60 dark:text-white/60 leading-relaxed mb-4">
              We were university students who wanted premium oversized streetwear — the kind you see on Instagram, the kind that makes you feel like you've made it — but every option was either cheaply made or cost more than our tuition.
            </p>
            <p className="text-black/60 dark:text-white/60 leading-relaxed mb-4">
              So we started MyTeeCanvas. A brand built around one idea: premium quality, minimal design, accessible price. No fast fashion shortcuts. No compromises on fabric weight or finish.
            </p>
            <p className="text-black/60 dark:text-white/60 leading-relaxed mb-8">
              Today we ship to thousands of students and young adults who believe that how you dress is how you choose to show up in the world. And they deserve the best.
            </p>
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 bg-black dark:bg-white text-white dark:text-black px-8 py-4 rounded-full font-semibold text-sm hover:opacity-90 transition-opacity"
            >
              Shop the Collection
              <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="aspect-[3/4] rounded-3xl overflow-hidden mt-8 img-zoom-container">
              <img
                src="https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&q=80"
                alt=""
                className="w-full h-full object-cover"
              />
            </div>
            <div className="aspect-[3/4] rounded-3xl overflow-hidden -mt-8 img-zoom-container">
              <img
                src="https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=500&q=80"
                alt=""
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-[#f5f0eb] dark:bg-black/40 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-14">
            <p className="text-xs font-semibold tracking-[0.2em] text-black/40 dark:text-white/40 uppercase mb-3">What We Stand For</p>
            <h2 className="text-3xl lg:text-4xl font-bold section-title">Our Values</h2>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((v, i) => (
              <div key={v.title} className="bg-white dark:bg-black/60 rounded-2xl p-6">
                <span className="text-3xl font-black text-black/10 dark:text-white/10 block mb-3 section-title">
                  0{i + 1}
                </span>
                <h3 className="font-bold mb-2">{v.title}</h3>
                <p className="text-sm text-black/60 dark:text-white/60 leading-relaxed">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="bg-black text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-10 text-center">
            {[
              { num: '3,000+', label: 'Happy Customers' },
              { num: '280 GSM', label: 'Minimum Fabric Weight' },
              { num: '48 hrs', label: 'Average Dispatch Time' },
              { num: '4.8★', label: 'Average Rating' },
            ].map((s) => (
              <div key={s.label}>
                <p className="text-4xl lg:text-5xl font-black mb-2 section-title">{s.num}</p>
                <p className="text-white/40 text-sm">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Manifesto */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-24 text-center">
        <p className="text-xs font-semibold tracking-[0.3em] text-black/40 dark:text-white/40 uppercase mb-6">
          Our Manifesto
        </p>
        <blockquote
          className="text-3xl lg:text-4xl font-bold section-title leading-relaxed text-black/80 dark:text-white/80"
        >
          "Wear what makes you feel unstoppable. Wear what tells your story before you say a word. Wear confidence."
        </blockquote>
        <p className="mt-6 text-black/40 dark:text-white/40 text-sm">— MyTeeCanvas</p>
      </section>
    </div>
  )
}
