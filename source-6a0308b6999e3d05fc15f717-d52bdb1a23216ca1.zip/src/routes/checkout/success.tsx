import { Link, createFileRoute } from '@tanstack/react-router'
import { Check, ArrowRight, ShoppingBag } from 'lucide-react'

export const Route = createFileRoute('/checkout/success')({
  component: CheckoutSuccess,
})

function CheckoutSuccess() {
  return (
    <div className="min-h-screen pt-20 flex items-center justify-center p-5 bg-[#f5f0eb] dark:bg-black">
      <div className="bg-white dark:bg-black/60 rounded-3xl p-12 shadow-xl text-center max-w-md w-full border border-black/8 dark:border-white/8 animate-scale-in">
        <div className="w-16 h-16 rounded-full bg-green-500 text-white flex items-center justify-center mx-auto mb-6">
          <Check size={28} />
        </div>
        <h1
          className="text-3xl font-bold section-title mb-3"
        >
          Order Confirmed!
        </h1>
        <p className="text-black/60 dark:text-white/60 mb-8 leading-relaxed">
          Thank you for shopping with MyTeeCanvas. Your order is being processed and you'll receive a confirmation email shortly.
        </p>
        <div className="space-y-3">
          <Link
            to="/shop"
            className="flex items-center justify-center gap-2 w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity"
          >
            <ShoppingBag size={16} />
            Continue Shopping
          </Link>
          <Link
            to="/"
            className="flex items-center justify-center gap-2 w-full border border-black/15 dark:border-white/15 py-4 rounded-xl font-semibold text-sm hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  )
}
