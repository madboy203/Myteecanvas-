import { Link, createFileRoute } from '@tanstack/react-router'
import { X, ShoppingBag } from 'lucide-react'

export const Route = createFileRoute('/checkout/cancel')({
  component: CheckoutCancel,
})

function CheckoutCancel() {
  return (
    <div className="min-h-screen pt-20 flex items-center justify-center p-5">
      <div className="bg-white dark:bg-black/60 rounded-3xl p-12 shadow-xl text-center max-w-md w-full border border-black/8 dark:border-white/8">
        <div className="w-16 h-16 rounded-full bg-red-100 dark:bg-red-900/30 text-red-500 flex items-center justify-center mx-auto mb-6">
          <X size={28} />
        </div>
        <h1 className="text-3xl font-bold section-title mb-3">Payment Cancelled</h1>
        <p className="text-black/60 dark:text-white/60 mb-8 leading-relaxed">
          No charges were made. Your cart is still saved. Return anytime to complete your purchase.
        </p>
        <div className="space-y-3">
          <Link
            to="/shop"
            className="flex items-center justify-center gap-2 w-full bg-black dark:bg-white text-white dark:text-black py-4 rounded-xl font-semibold text-sm hover:opacity-90 transition-opacity"
          >
            <ShoppingBag size={16} />
            Return to Shop
          </Link>
          <Link
            to="/"
            className="flex items-center justify-center w-full border border-black/15 dark:border-white/15 py-4 rounded-xl font-semibold text-sm hover:bg-black/5 dark:hover:bg-white/5 transition-colors"
          >
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  )
}
