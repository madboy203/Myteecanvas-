export interface Product {
  id: number
  name: string
  category: 'oversized' | 'polo' | 'basic-tee' | 'streetwear' | 'hoodie'
  image: string
  images: string[]
  description: string
  shortDescription: string
  price: number
  originalPrice?: number
  sizes: string[]
  colors: string[]
  fabric: string
  isNew?: boolean
  isBestSeller?: boolean
  isTrending?: boolean
  isLimitedEdition?: boolean
  stock: number
  soldThisWeek: number
  rating: number
  reviewCount: number
  tags: string[]
}

const products: Array<Product> = [
  {
    id: 1,
    name: 'Shadow Drop Shoulder Tee',
    category: 'oversized',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80',
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&q=80',
      'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&q=80',
    ],
    description:
      'The Shadow Drop Shoulder Tee is crafted from 100% premium ringspun cotton with a relaxed boxy silhouette. Featuring extended drop shoulders, a crew neck, and an oversized fit — perfect for layering or wearing solo. The heavyweight fabric (280 GSM) ensures a premium feel that holds its shape wash after wash.',
    shortDescription: 'Premium 280 GSM oversized drop shoulder tee.',
    price: 29,
    originalPrice: 39,
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'White', 'Stone', 'Slate Grey'],
    fabric: '100% Ringspun Cotton, 280 GSM',
    isNew: true,
    isBestSeller: true,
    stock: 7,
    soldThisWeek: 134,
    rating: 4.8,
    reviewCount: 89,
    tags: ['oversized', 'drop shoulder', 'premium', 'streetwear'],
  },
  {
    id: 2,
    name: 'Void Polo Shirt',
    category: 'polo',
    image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&q=80',
      'https://images.unsplash.com/photo-1594938298603-c8148c4b4357?w=600&q=80',
    ],
    description:
      'The Void Polo merges classic structure with modern streetwear aesthetics. Made from a soft cotton-piqué blend, this slim-to-regular fit polo features a ribbed collar, two-button placket, and subtle logo at the chest. Versatile enough for casual outings to late-night hangouts.',
    shortDescription: 'Minimalist slim polo with ribbed collar.',
    price: 35,
    originalPrice: 45,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'White', 'Navy', 'Beige'],
    fabric: '95% Cotton 5% Elastane Piqué, 220 GSM',
    isTrending: true,
    stock: 15,
    soldThisWeek: 98,
    rating: 4.7,
    reviewCount: 62,
    tags: ['polo', 'minimal', 'slim fit', 'casual'],
  },
  {
    id: 3,
    name: 'Blank Canvas Tee',
    category: 'basic-tee',
    image: 'https://images.unsplash.com/photo-1564584217132-2271feaeb3c5?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1564584217132-2271feaeb3c5?w=600&q=80',
      'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&q=80',
    ],
    description:
      'The Blank Canvas Tee is your everyday essential — a perfectly proportioned regular fit t-shirt with a slightly longer body and subtle side seams. Made from soft combed cotton, it drapes beautifully and keeps its structure. The foundation of any wardrobe.',
    shortDescription: 'Essential regular-fit tee, combed cotton.',
    price: 22,
    sizes: ['XS', 'S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'White', 'Charcoal', 'Cream', 'Sage'],
    fabric: '100% Combed Cotton, 200 GSM',
    isBestSeller: true,
    stock: 32,
    soldThisWeek: 210,
    rating: 4.9,
    reviewCount: 148,
    tags: ['basic', 'essential', 'everyday', 'minimal'],
  },
  {
    id: 4,
    name: 'Nocturne Oversized Hoodie',
    category: 'hoodie',
    image: 'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1556821840-3a63f15732ce?w=600&q=80',
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&q=80',
    ],
    description:
      'The Nocturne Hoodie is built for those who live in the grey zone between comfort and style. Heavy 380 GSM fleece interior, dropped shoulders, kangaroo pocket, and ribbed cuffs. An anti-fit silhouette that looks intentional at every angle.',
    shortDescription: '380 GSM heavyweight oversized hoodie.',
    price: 65,
    originalPrice: 79,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'Charcoal', 'Stone'],
    fabric: '80% Cotton 20% Polyester Fleece, 380 GSM',
    isLimitedEdition: true,
    isTrending: true,
    stock: 5,
    soldThisWeek: 47,
    rating: 4.9,
    reviewCount: 33,
    tags: ['hoodie', 'heavyweight', 'oversized', 'limited edition'],
  },
  {
    id: 5,
    name: 'Urban Ghost Streetwear Set',
    category: 'streetwear',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=600&q=80',
      'https://images.unsplash.com/photo-1460353581641-37baddab0fa2?w=600&q=80',
    ],
    description:
      'The Urban Ghost set is for those who move through the city with intention. Oversized graphic tee with a distressed print on the front, paired with a matching aesthetic. Made for the streets, designed for the gram.',
    shortDescription: 'Graphic oversized tee with urban aesthetic.',
    price: 38,
    originalPrice: 52,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black', 'Off-White'],
    fabric: '100% Ringspun Cotton, 260 GSM',
    isTrending: true,
    isNew: true,
    stock: 12,
    soldThisWeek: 86,
    rating: 4.6,
    reviewCount: 44,
    tags: ['streetwear', 'graphic', 'oversized', 'urban'],
  },
  {
    id: 6,
    name: 'Minimal Arch Tee',
    category: 'basic-tee',
    image: 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=600&q=80',
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80',
    ],
    description:
      'Clean lines. Quiet luxury. The Minimal Arch Tee features a subtle embossed arch logo on the left chest — a signature of understated premium fashion. The boxy regular fit and medium-weight cotton make it the perfect companion for any outfit.',
    shortDescription: 'Boxy fit tee with embossed arch logo.',
    price: 26,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'White', 'Beige', 'Dusty Rose'],
    fabric: '100% Combed Cotton, 220 GSM',
    isNew: true,
    stock: 20,
    soldThisWeek: 72,
    rating: 4.7,
    reviewCount: 55,
    tags: ['minimal', 'logo', 'boxy', 'premium'],
  },
  {
    id: 7,
    name: 'Phantom Drop Shoulder — Black',
    category: 'oversized',
    image: 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=600&q=80',
      'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=600&q=80',
    ],
    description:
      'The Phantom is our darkest drop shoulder tee — heavy black dye, relaxed oversized body, extended arm length, and subtle hem detailing. Designed for those who prefer to let the fit do the talking.',
    shortDescription: 'All-black heavyweight drop shoulder.',
    price: 33,
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    colors: ['Black'],
    fabric: '100% Ringspun Cotton, 300 GSM',
    isBestSeller: true,
    stock: 9,
    soldThisWeek: 120,
    rating: 4.8,
    reviewCount: 91,
    tags: ['oversized', 'black', 'drop shoulder', 'premium'],
  },
  {
    id: 8,
    name: 'Canvas Ribbed Polo',
    category: 'polo',
    image: 'https://images.unsplash.com/photo-1594938298603-c8148c4b4357?w=600&q=80',
    images: [
      'https://images.unsplash.com/photo-1594938298603-c8148c4b4357?w=600&q=80',
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&q=80',
    ],
    description:
      'The Canvas Ribbed Polo features a full-ribbed knit construction for a textured, luxurious feel. A relaxed silhouette, open collar, and tonal buttons give it a clean modern edge. Versatile enough to dress up or keep casual.',
    shortDescription: 'Ribbed knit polo with open collar.',
    price: 42,
    originalPrice: 55,
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    colors: ['Black', 'Cream', 'Brown'],
    fabric: '100% Cotton Rib Knit, 240 GSM',
    isLimitedEdition: true,
    stock: 8,
    soldThisWeek: 38,
    rating: 4.7,
    reviewCount: 27,
    tags: ['polo', 'ribbed', 'knit', 'premium', 'limited'],
  },
]

export default products
